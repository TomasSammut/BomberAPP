import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, ResponsiveContainer, Tooltip } from 'recharts';
import type { TestScore, UserProfile, Opposition, SessionRecord } from '../types';
import SettingsModal from '../components/SettingsModal';
import { tests } from '../scoring';

const fallbackProgram: Record<number, { title: string; type: string }> = {
  0: { title: 'Descanso Activo / Movilidad', type: 'rest' },
  1: { title: 'Fuerza: Tren Superior', type: 'strength' },
  2: { title: 'Resistencia: Series de 1000m', type: 'athletics' },
  3: { title: 'Técnica de Oposición (Fuerza)', type: 'strength' },
  4: { title: 'Natación: Específico', type: 'swimming' },
  5: { title: 'Carrera Continua / HIIT', type: 'athletics' },
  6: { title: 'Simulacro / Combinado', type: 'athletics' },
};

const typeColor: Record<string, string> = {
  rest: '#94a3b8',
  active_recovery: '#94a3b8',
  strength: '#f97316',
  athletics: '#38bdf8',
  swimming: '#22c55e',
};

const typeLabel: Record<string, string> = {
  rest: 'DESCANSO',
  active_recovery: 'RECUPERACIÓN',
  strength: 'FUERZA',
  athletics: 'ATLETISMO',
  swimming: 'NATACIÓN',
};

const testEmoji: Record<string, string> = {
  'Cuerda': '🪢',
  '3000m': '🏃',
  '60m': '⚡',
  'Natacion': '🏊',
  'Press Banca': '🏋️',
  'Torre': '🏗️',
};

interface HomeProps {
  stats: TestScore[];
  profile: UserProfile;
  opposition: Opposition;
  wod: string;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onResetData: () => void;
  history: SessionRecord[];
}

const Home: React.FC<HomeProps> = ({ stats, profile, opposition, onUpdateProfile, onResetData, history }) => {
  const navigate = useNavigate();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const today = new Date().getDay();

  const todayWorkout = useMemo(() => {
    const planDay = profile.trainingPlan?.weeklySchedule?.[today];
    if (planDay) return { title: planDay.title, type: planDay.type || 'athletics' };
    return fallbackProgram[today];
  }, [profile.trainingPlan, today]);

  const daysUntilExam = useMemo(() => {
    if (!profile.examDate) return null;
    const exam = new Date(profile.examDate);
    const now = new Date();
    exam.setHours(0, 0, 0, 0);
    now.setHours(0, 0, 0, 0);
    const diff = Math.ceil((exam.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff > 0 ? diff : null;
  }, [profile.examDate]);

  const totalScore = stats.reduce((acc, s) => acc + s.score, 0);
  const maxScore = tests.length * 10;
  const readinessPct = Math.round((totalScore / maxScore) * 100);
  const aptosCount = stats.filter(s => s.score >= 5 && s.value).length;
  const hasAnyMark = stats.some(s => s.value);

  const chartData = useMemo(() => {
    return [...history]
      .filter(h => h.type === 'mark')
      .sort((a, b) => a.timestamp - b.timestamp)
      .slice(-10)
      .map(h => ({
        score: h.totalScore,
        date: new Date(h.timestamp).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' }),
      }));
  }, [history]);

  const weakestTest = useMemo(() => {
    const withMarks = stats.filter(s => s.value);
    if (withMarks.length === 0) return null;
    return withMarks.reduce((prev, curr) => (curr.score < prev.score ? curr : prev));
  }, [stats]);

  const wodColor = typeColor[todayWorkout.type] || '#f97316';
  const wodLabel = typeLabel[todayWorkout.type] || 'HOY';

  const avatars: Record<string, string> = {
    '1': '👨‍🚒', '2': '👩‍🚒', '3': '🚒', '4': '🦁', '5': '🦅', '6': '⚡'
  };

  const getScoreColor = (score: number, hasValue: boolean) => {
    if (!hasValue) return 'rgba(255,255,255,0.15)';
    if (score === 0) return '#ef4444';
    if (score >= 9) return '#22c55e';
    if (score >= 7) return '#f97316';
    return '#f59e0b';
  };

  return (
    <div className="page-content" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* HEADER */}
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 'calc(14px + env(safe-area-inset-top)) 20px 14px',
        borderBottom: '1px solid rgba(255,255,255,0.05)',
      }}>
        <div
          onClick={() => setIsSettingsOpen(true)}
          style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}
        >
          <span style={{ fontSize: '24px' }}>{avatars[profile.avatarId || '1']}</span>
          <div>
            <p style={{ margin: 0, fontSize: '15px', fontWeight: '800', color: 'white' }}>{profile.name}</p>
            <p style={{ margin: 0, fontSize: '11px', color: 'var(--text-muted)' }}>{opposition.shortName}</p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {profile.streak && profile.streak > 0 ? (
            <div style={{ textAlign: 'center' }}>
              <p style={{ margin: 0, fontSize: '16px', fontWeight: '900', color: 'var(--primary)' }}>🔥 {profile.streak}</p>
              <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>racha</p>
            </div>
          ) : null}
          {daysUntilExam !== null ? (
            <div
              style={{
                background: daysUntilExam < 30 ? 'rgba(239,68,68,0.12)' : 'rgba(249,115,22,0.1)',
                border: `1px solid ${daysUntilExam < 30 ? 'rgba(239,68,68,0.4)' : 'rgba(249,115,22,0.3)'}`,
                borderRadius: '12px',
                padding: '6px 12px',
                textAlign: 'center',
                cursor: 'pointer',
              }}
              onClick={() => setIsSettingsOpen(true)}
            >
              <p style={{ margin: 0, fontSize: '18px', fontWeight: '900', color: daysUntilExam < 30 ? '#ef4444' : 'var(--primary)' }}>
                {daysUntilExam}
              </p>
              <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>días</p>
            </div>
          ) : (
            <div
              onClick={() => setIsSettingsOpen(true)}
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px dashed rgba(255,255,255,0.15)',
                borderRadius: '12px',
                padding: '6px 12px',
                cursor: 'pointer',
              }}
            >
              <p style={{ margin: 0, fontSize: '10px', color: 'var(--text-muted)', textAlign: 'center' }}>📅{'\n'}Examen</p>
            </div>
          )}
        </div>
      </header>

      <main className="main" style={{ paddingTop: '16px', paddingBottom: '20px' }}>

        {/* CARD WOD */}
        <section
          className="card"
          onClick={() => navigate('/training')}
          style={{
            background: `linear-gradient(135deg, ${wodColor}18 0%, rgba(30,41,59,0.6) 100%)`,
            border: `1px solid ${wodColor}40`,
            padding: '16px 20px',
            marginBottom: '14px',
            cursor: 'pointer',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div style={{ flex: 1 }}>
              <span style={{
                fontSize: '9px',
                fontWeight: '900',
                color: wodColor,
                textTransform: 'uppercase',
                letterSpacing: '1.5px',
              }}>
                {wodLabel} · HOY
              </span>
              <p style={{ margin: '4px 0 0', fontSize: '17px', fontWeight: '800', color: 'white', lineHeight: 1.3 }}>
                {todayWorkout.title}
              </p>
            </div>
            <span style={{ fontSize: '28px', marginLeft: '12px' }}>
              {todayWorkout.type === 'rest' || todayWorkout.type === 'active_recovery' ? '😴' :
               todayWorkout.type === 'strength' ? '💪' :
               todayWorkout.type === 'swimming' ? '🏊' : '🏃'}
            </span>
          </div>
          <p style={{ margin: '8px 0 0', fontSize: '11px', color: 'var(--text-muted)' }}>
            Toca para ver los ejercicios →
          </p>
        </section>

        {/* CARD BIG 6 */}
        <section className="card" style={{ padding: '16px 20px', marginBottom: '14px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <span style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>
              Tus 6 Pruebas
            </span>
            <span
              onClick={() => navigate('/calculator')}
              style={{ fontSize: '11px', color: 'var(--primary)', fontWeight: '700', cursor: 'pointer' }}
            >
              Actualizar →
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
            {stats.map((s) => {
              const hasValue = !!s.value;
              const scoreColor = getScoreColor(s.score, hasValue);
              return (
                <div
                  key={s.name}
                  onClick={() => navigate('/calculator')}
                  style={{
                    background: hasValue ? `${scoreColor}14` : 'rgba(255,255,255,0.03)',
                    border: `1px solid ${hasValue ? `${scoreColor}40` : 'rgba(255,255,255,0.06)'}`,
                    borderRadius: '14px',
                    padding: '12px 10px',
                    textAlign: 'center',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ fontSize: '18px', marginBottom: '4px' }}>
                    {testEmoji[s.name] || '🏅'}
                  </div>
                  <div style={{
                    fontSize: '20px',
                    fontWeight: '900',
                    color: hasValue ? scoreColor : 'rgba(255,255,255,0.2)',
                    lineHeight: 1,
                  }}>
                    {hasValue ? s.score : '–'}
                  </div>
                  <div style={{
                    fontSize: '9px',
                    color: 'var(--text-muted)',
                    textTransform: 'uppercase',
                    marginTop: '4px',
                    letterSpacing: '0.5px',
                  }}>
                    {s.name === 'Natacion' ? 'Natación' : s.name === 'Press Banca' ? 'Banca' : s.name}
                  </div>
                  {hasValue && (
                    <div style={{ fontSize: '10px', color: 'rgba(255,255,255,0.35)', marginTop: '2px' }}>
                      {s.value}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {hasAnyMark && (
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: '14px',
              paddingTop: '12px',
              borderTop: '1px solid rgba(255,255,255,0.06)',
            }}>
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                {aptosCount}/{tests.length} aptas · {readinessPct}% preparación
              </span>
              <div style={{
                background: readinessPct >= 70 ? 'rgba(34,197,94,0.15)' : 'rgba(249,115,22,0.15)',
                border: `1px solid ${readinessPct >= 70 ? 'rgba(34,197,94,0.4)' : 'rgba(249,115,22,0.3)'}`,
                borderRadius: '8px',
                padding: '3px 10px',
              }}>
                <span style={{
                  fontSize: '13px',
                  fontWeight: '900',
                  color: readinessPct >= 70 ? '#22c55e' : 'var(--primary)',
                }}>
                  {totalScore.toFixed(1)} pts
                </span>
              </div>
            </div>
          )}

          {!hasAnyMark && (
            <div
              onClick={() => navigate('/calculator')}
              style={{
                marginTop: '12px',
                padding: '12px',
                background: 'rgba(249,115,22,0.07)',
                border: '1px dashed rgba(249,115,22,0.3)',
                borderRadius: '12px',
                textAlign: 'center',
                cursor: 'pointer',
              }}
            >
              <p style={{ margin: 0, fontSize: '12px', color: 'var(--primary)', fontWeight: '700' }}>
                + Registra tus primeras marcas
              </p>
            </div>
          )}
        </section>

        {/* CARD EVOLUCIÓN */}
        <section className="card" style={{ padding: '16px 20px', marginBottom: '14px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>
              Evolución Global
            </span>
            <span
              onClick={() => navigate('/progress')}
              style={{ fontSize: '11px', color: 'var(--primary)', fontWeight: '700', cursor: 'pointer' }}
            >
              Ver detalles →
            </span>
          </div>

          {chartData.length >= 2 ? (
            <ResponsiveContainer width="100%" height={90}>
              <LineChart data={chartData} margin={{ top: 4, right: 4, bottom: 0, left: -30 }}>
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#f97316"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#f97316', strokeWidth: 0 }}
                  activeDot={{ r: 5, fill: '#f97316' }}
                />
                <Tooltip
                  contentStyle={{
                    background: '#1e293b',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: 'white',
                  }}
                  formatter={(val: any) => [`${Number(val).toFixed(1)} pts`, '']}
                  labelFormatter={(label: any) => String(label)}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height: '70px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <p style={{ fontSize: '12px', color: 'var(--text-muted)', textAlign: 'center', margin: 0 }}>
                Registra al menos 2 sesiones para ver tu evolución
              </p>
            </div>
          )}
        </section>

        {/* ALERTA PRUEBA DÉBIL */}
        {weakestTest && weakestTest.score < 7 && (
          <section
            className="card"
            onClick={() => navigate('/training')}
            style={{
              background: weakestTest.score === 0 ? 'rgba(239,68,68,0.08)' : 'rgba(245,158,11,0.08)',
              border: `1px solid ${weakestTest.score === 0 ? 'rgba(239,68,68,0.3)' : 'rgba(245,158,11,0.25)'}`,
              padding: '14px 18px',
              cursor: 'pointer',
              marginBottom: '0',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '28px' }}>{weakestTest.score === 0 ? '🚨' : '⚠️'}</span>
              <div>
                <p style={{
                  margin: 0,
                  fontSize: '11px',
                  fontWeight: '900',
                  color: weakestTest.score === 0 ? '#ef4444' : '#f59e0b',
                  textTransform: 'uppercase',
                  letterSpacing: '0.5px',
                }}>
                  {weakestTest.score === 0 ? 'Prueba eliminatoria' : 'Prueba a mejorar'}
                </p>
                <p style={{ margin: '2px 0 0', fontSize: '14px', fontWeight: '800', color: 'white' }}>
                  {testEmoji[weakestTest.name]} {weakestTest.name === 'Natacion' ? 'Natación' : weakestTest.name} · {weakestTest.score} pts
                </p>
              </div>
              <span style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: '16px' }}>→</span>
            </div>
          </section>
        )}

      </main>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        profile={profile}
        onUpdateProfile={onUpdateProfile}
        onResetData={onResetData}
      />
    </div>
  );
};

export default Home;
