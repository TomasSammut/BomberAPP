import React, { useState, useMemo, useEffect, useRef } from 'react';
import { calculateScore, tests, getNextThresholdHint, allScoringCriteria, oppositions, parseValue } from '../scoring';
import type { UserProfile, TestScore, SessionRecord } from '../types';

interface CalculatorProps {
  profile: UserProfile;
  history: SessionRecord[];
  onSaveSession: (timestamp?: number, specificScores?: TestScore[]) => void;
}

// Metadatos visuales y de ayuda por prueba
const testMeta: Record<string, { emoji: string; label: string; formatHint: string; exampleValue: string }> = {
  'Cuerda':      { emoji: '🪢', label: 'Cuerda',    formatHint: 'segundos (ej. 8.5)',   exampleValue: '8.5'  },
  '3000m':       { emoji: '🏃', label: '3000m',     formatHint: 'min:seg (ej. 11:20)',  exampleValue: '11:20'},
  '60m':         { emoji: '⚡', label: '60m',       formatHint: 'segundos (ej. 7.85)',  exampleValue: '7.85' },
  'Natacion':    { emoji: '🏊', label: 'Natación',  formatHint: 'min:seg (ej. 1:18)',   exampleValue: '1:18' },
  'Press Banca': { emoji: '🏋️', label: 'Banca',     formatHint: 'repeticiones (ej. 28)',exampleValue: '28'   },
  'Torre':       { emoji: '🏗️', label: 'Torre',     formatHint: 'segundos (ej. 26.5)',  exampleValue: '26.5' },
};

const getScoreColor = (score: number): string => {
  if (score === 0)  return '#ef4444';
  if (score >= 9)   return '#22c55e';
  if (score >= 7)   return '#f97316';
  return '#f59e0b';
};

// Comprueba si un valor es una mejora respecto al récord anterior
const isBetterThan = (newVal: string, oldVal: string, testName: string, oppId: string): boolean => {
  const opp = oppositions.find(o => o.id === oppId) || oppositions[0];
  const criteria = allScoringCriteria[opp.scoringTable]?.[testName];
  if (!criteria) return false;
  const nv = parseValue(newVal, criteria.unit);
  const ov = parseValue(oldVal, criteria.unit);
  if (isNaN(nv) || isNaN(ov)) return false;
  return criteria.betterIs === 'lower' ? nv < ov : nv > ov;
};

const Calculator: React.FC<CalculatorProps> = ({ profile, history, onSaveSession }) => {
  const [editingTest, setEditingTest] = useState<string | null>(null);
  const [localInput, setLocalInput]   = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Marcas más recientes (globales)
  const latestMarks = useMemo(() => {
    const latest: Record<string, string> = {};
    const sorted = [...history].sort((a, b) => b.timestamp - a.timestamp);
    tests.forEach(test => {
      const rec = sorted.find(s =>
        s.type === 'mark' && s.scores.some(ts => ts.name === test.name && ts.value?.trim())
      );
      if (rec) {
        const sc = rec.scores.find(ts => ts.name === test.name);
        if (sc) latest[test.name] = sc.value;
      }
    });
    return latest;
  }, [history]);

  // Marcas del día seleccionado
  const dayInputs = useMemo(() => {
    const rec = history.find(h =>
      h.type === 'mark' &&
      new Date(h.timestamp).toISOString().split('T')[0] === selectedDate
    );
    const inputs: Record<string, string> = {};
    rec?.scores.forEach(s => { inputs[s.name] = s.value; });
    return inputs;
  }, [history, selectedDate]);

  // Al cambiar fecha o prueba seleccionada, sincronizar input
  useEffect(() => {
    if (editingTest) {
      setLocalInput(dayInputs[editingTest] || '');
    }
  }, [selectedDate, editingTest]);

  // Autofocus al abrir edición
  useEffect(() => {
    if (editingTest) {
      setTimeout(() => inputRef.current?.focus(), 80);
    }
  }, [editingTest]);

  const openEdit = (testName: string) => {
    setConfirmDelete(null);
    setEditingTest(testName);
    setLocalInput(dayInputs[testName] || '');
  };

  const closeEdit = () => {
    setEditingTest(null);
    setLocalInput('');
    setConfirmDelete(null);
  };

  const handleSave = (testName: string) => {
    const trimmed = localInput.trim();

    // Intentar borrar con campo vacío → pedir confirmación si había marca
    if (trimmed === '' && dayInputs[testName]) {
      setConfirmDelete(testName);
      return;
    }

    const scoreObj = trimmed === ''
      ? { name: testName, value: '', score: 0 }
      : calculateScore(testName, trimmed, profile.gender, profile.activeOppositionId);

    const [y, m, d] = selectedDate.split('-').map(Number);
    const ts = new Date(y, m - 1, d, 12, 0, 0).getTime();
    onSaveSession(ts, [scoreObj as TestScore]);
    closeEdit();
  };

  const handleConfirmDelete = (testName: string) => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const ts = new Date(y, m - 1, d, 12, 0, 0).getTime();
    onSaveSession(ts, [{ name: testName, value: '', score: 0 }]);
    closeEdit();
  };

  // Puntuación global (marcas más recientes)
  const globalScore = useMemo(() =>
    tests.reduce((acc, t) => {
      const v = latestMarks[t.name] || '';
      return acc + calculateScore(t.name, v, profile.gender, profile.activeOppositionId).score;
    }, 0),
    [latestMarks, profile.gender, profile.activeOppositionId]
  );

  const allApto = tests.every(t => {
    const v = latestMarks[t.name] || '';
    return v ? calculateScore(t.name, v, profile.gender, profile.activeOppositionId).score >= 5 : false;
  });

  const isToday = selectedDate === new Date().toISOString().split('T')[0];

  return (
    <div style={{ paddingTop: 'calc(10px + env(safe-area-inset-top))', paddingBottom: '120px' }}>

      {/* CABECERA: puntuación global */}
      <div style={{ textAlign: 'center', padding: '10px 20px 18px' }}>
        <p style={{ margin: 0, fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '2px' }}>
          Nota global · {profile.gender === 'male' ? 'Hombre' : 'Mujer'}
        </p>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: '6px', margin: '4px 0' }}>
          <span style={{ fontSize: '44px', fontWeight: '900', color: 'white', letterSpacing: '-2px', lineHeight: 1 }}>
            {globalScore.toFixed(1)}
          </span>
          <span style={{ fontSize: '16px', color: 'var(--text-muted)' }}>/ 60</span>
        </div>
        <span style={{
          display: 'inline-block',
          fontSize: '11px', fontWeight: '900',
          padding: '3px 12px', borderRadius: '99px',
          background: allApto ? 'rgba(34,197,94,0.15)' : 'rgba(249,115,22,0.12)',
          color: allApto ? '#22c55e' : 'var(--primary)',
          border: `1px solid ${allApto ? 'rgba(34,197,94,0.3)' : 'rgba(249,115,22,0.25)'}`,
        }}>
          {allApto ? '✓ APTO' : 'Basado en tus últimas marcas'}
        </span>
      </div>

      {/* SELECTOR DE FECHA GLOBAL */}
      <div style={{ padding: '0 20px 16px' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: '10px',
          background: 'var(--card-bg)',
          border: '1px solid rgba(255,255,255,0.07)',
          borderRadius: '14px',
          padding: '10px 14px',
        }}>
          <span style={{ fontSize: '16px' }}>📅</span>
          <div style={{ flex: 1 }}>
            <p style={{ margin: 0, fontSize: '9px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>
              Fecha de la marca
            </p>
            <p style={{ margin: 0, fontSize: '13px', fontWeight: '700', color: 'white' }}>
              {isToday ? 'Hoy · ' : ''}{new Date(selectedDate + 'T12:00:00').toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
          </div>
          <input
            type="date"
            value={selectedDate}
            max={new Date().toISOString().split('T')[0]}
            onChange={e => setSelectedDate(e.target.value)}
            style={{
              background: 'rgba(249,115,22,0.1)',
              border: '1px solid rgba(249,115,22,0.3)',
              borderRadius: '8px',
              color: 'var(--primary)',
              fontSize: '12px',
              fontWeight: '900',
              padding: '6px 8px',
            }}
          />
        </div>
      </div>

      {/* GRID DE PRUEBAS */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', padding: '0 20px' }}>
        {tests.map((test) => {
          const meta      = testMeta[test.name] || { emoji: '🏅', label: test.name, formatHint: '', exampleValue: '' };
          const isEditing = editingTest === test.name;
          const isDeleting = confirmDelete === test.name;

          const latestVal = latestMarks[test.name] || '';
          const dayVal    = dayInputs[test.name] || '';

          const displayVal = latestVal; // valor actual para la card cerrada
          const bestMark   = profile.bestMarks?.[test.name]?.value || '';

          const latestScore = calculateScore(test.name, latestVal, profile.gender, profile.activeOppositionId);
          const scoreColor  = latestVal ? getScoreColor(latestScore.score) : 'rgba(255,255,255,0.15)';

          // Puntuación en tiempo real mientras se edita
          const liveScore = localInput.trim()
            ? calculateScore(test.name, localInput, profile.gender, profile.activeOppositionId)
            : null;
          const liveColor = liveScore ? getScoreColor(liveScore.score) : 'rgba(255,255,255,0.2)';

          // Hint de distancia al siguiente umbral
          const hint = liveScore && localInput.trim()
            ? getNextThresholdHint(test.name, localInput, profile.gender, profile.activeOppositionId)
            : null;

          // ¿Es récord personal?
          const isNewPB = liveScore && localInput.trim() && bestMark
            ? isBetterThan(localInput, bestMark, test.name, profile.activeOppositionId)
            : false;

          // Progreso visual (0-100%) hacia el 10
          const progressPct = latestScore.score > 0 ? (latestScore.score / 10) * 100 : 0;

          return (
            <div
              key={test.name}
              onClick={() => { if (!isEditing && !isDeleting) openEdit(test.name); }}
              style={{
                background: isEditing ? 'rgba(255,255,255,0.07)' : 'var(--card-bg)',
                borderRadius: '20px',
                padding: '16px',
                border: isEditing
                  ? '2px solid var(--primary)'
                  : `1px solid ${latestVal ? scoreColor + '30' : 'rgba(255,255,255,0.05)'}`,
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                cursor: isEditing ? 'default' : 'pointer',
                transition: 'border-color 0.2s',
              }}
            >
              {/* CABECERA DE CARD */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ fontSize: '16px' }}>{meta.emoji}</span>
                  <span style={{ fontSize: '11px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                    {meta.label}
                  </span>
                </div>
                {latestVal && !isEditing && (
                  <span style={{
                    fontSize: '13px', fontWeight: '900',
                    color: scoreColor,
                  }}>
                    {latestScore.score}
                  </span>
                )}
              </div>

              {/* MODO EDICIÓN */}
              {isEditing && !isDeleting && (
                <div onClick={e => e.stopPropagation()} style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>

                  {/* INPUT PRINCIPAL */}
                  <div style={{ position: 'relative' }}>
                    <input
                      ref={inputRef}
                      type="text"
                      inputMode="decimal"
                      value={localInput}
                      onChange={e => setLocalInput(e.target.value)}
                      placeholder={meta.exampleValue}
                      style={{
                        width: '100%',
                        background: 'rgba(255,255,255,0.92)',
                        border: `2px solid ${liveScore ? liveColor : 'rgba(255,255,255,0.2)'}`,
                        borderRadius: '10px',
                        color: 'black',
                        fontSize: '22px',
                        fontWeight: '900',
                        padding: '10px 12px',
                        textAlign: 'center',
                        transition: 'border-color 0.2s',
                      }}
                    />
                    {/* Formato hint — solo si el campo está vacío */}
                    {!localInput && (
                      <p style={{
                        position: 'absolute',
                        bottom: '-18px',
                        left: 0, right: 0,
                        margin: 0,
                        fontSize: '10px',
                        color: 'rgba(255,255,255,0.3)',
                        textAlign: 'center',
                        fontStyle: 'italic',
                        pointerEvents: 'none',
                      }}>
                        {meta.formatHint}
                      </p>
                    )}
                  </div>

                  {/* FEEDBACK EN VIVO */}
                  <div style={{ minHeight: '36px', marginTop: localInput ? '0' : '12px' }}>
                    {liveScore && localInput.trim() ? (
                      <div style={{
                        background: `${liveColor}15`,
                        border: `1px solid ${liveColor}40`,
                        borderRadius: '10px',
                        padding: '6px 10px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}>
                        <span style={{ fontSize: '18px', fontWeight: '900', color: liveColor }}>
                          {liveScore.score === 0 ? '✗ No apto' : `${liveScore.score} pts`}
                        </span>
                        <div style={{ textAlign: 'right' }}>
                          {isNewPB && (
                            <p style={{ margin: 0, fontSize: '10px', fontWeight: '900', color: '#facc15' }}>🏆 Nuevo récord</p>
                          )}
                          {hint && liveScore.score > 0 && (
                            <p style={{ margin: 0, fontSize: '10px', color: 'var(--text-muted)' }}>
                              {hint.diff}{hint.unit} → {hint.points} pts
                            </p>
                          )}
                          {liveScore.score >= 10 && (
                            <p style={{ margin: 0, fontSize: '10px', color: '#22c55e' }}>Puntuación máxima</p>
                          )}
                        </div>
                      </div>
                    ) : null}
                  </div>

                  {/* BOTONES */}
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button
                      onClick={() => handleSave(test.name)}
                      style={{
                        flex: 1,
                        background: localInput.trim() ? 'var(--primary)' : 'rgba(239,68,68,0.15)',
                        color: localInput.trim() ? 'black' : '#ef4444',
                        border: localInput.trim() ? 'none' : '1px solid rgba(239,68,68,0.3)',
                        borderRadius: '10px',
                        padding: '11px',
                        fontSize: '12px',
                        fontWeight: '900',
                        letterSpacing: '0.5px',
                      }}
                    >
                      {!localInput.trim() && dayVal ? 'Borrar marca' : 'Guardar'}
                    </button>
                    <button
                      onClick={closeEdit}
                      style={{
                        background: 'rgba(255,255,255,0.07)',
                        color: 'var(--text-muted)',
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '10px',
                        padding: '11px 14px',
                        fontSize: '16px',
                      }}
                    >
                      ✕
                    </button>
                  </div>

                  {/* Info de marca del día si existe */}
                  {dayVal && (
                    <p style={{ margin: 0, fontSize: '10px', color: 'rgba(255,255,255,0.25)', textAlign: 'center' }}>
                      Marca guardada este día: <span style={{ color: 'rgba(255,255,255,0.45)', fontWeight: '700' }}>{dayVal}</span>
                    </p>
                  )}
                </div>
              )}

              {/* CONFIRMACIÓN BORRADO */}
              {isDeleting && (
                <div onClick={e => e.stopPropagation()} style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <p style={{ margin: 0, fontSize: '12px', color: 'white', textAlign: 'center', lineHeight: 1.4 }}>
                    ¿Eliminar la marca <strong>{dayVal}</strong> del {new Date(selectedDate + 'T12:00:00').toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}?
                  </p>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button
                      onClick={() => handleConfirmDelete(test.name)}
                      style={{
                        flex: 1, background: 'rgba(239,68,68,0.15)', color: '#ef4444',
                        border: '1px solid rgba(239,68,68,0.3)', borderRadius: '10px',
                        padding: '10px', fontSize: '12px', fontWeight: '900',
                      }}
                    >
                      Sí, borrar
                    </button>
                    <button
                      onClick={closeEdit}
                      style={{
                        flex: 1, background: 'rgba(255,255,255,0.07)', color: 'white',
                        border: '1px solid rgba(255,255,255,0.1)', borderRadius: '10px',
                        padding: '10px', fontSize: '12px', fontWeight: '700',
                      }}
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}

              {/* MODO LECTURA */}
              {!isEditing && !isDeleting && (
                <>
                  {/* Valor actual */}
                  <div>
                    {displayVal ? (
                      <p style={{ margin: 0, fontSize: '22px', fontWeight: '900', color: 'white', lineHeight: 1 }}>
                        {displayVal}
                        <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: '400', marginLeft: '4px' }}>
                          {test.unit === 'reps' ? 'reps' : test.unit === 'seconds' ? 's' : ''}
                        </span>
                      </p>
                    ) : (
                      <p style={{ margin: 0, fontSize: '14px', color: 'rgba(255,255,255,0.18)', fontStyle: 'italic' }}>
                        Sin marca
                      </p>
                    )}

                    {/* Récord personal */}
                    {bestMark && bestMark !== displayVal && (
                      <p style={{ margin: '4px 0 0', fontSize: '10px', color: '#facc15', fontWeight: '700' }}>
                        🏆 Récord: {bestMark}
                      </p>
                    )}
                    {bestMark && bestMark === displayVal && displayVal && (
                      <p style={{ margin: '4px 0 0', fontSize: '10px', color: '#facc15', fontWeight: '700' }}>
                        🏆 Récord personal
                      </p>
                    )}
                  </div>

                  {/* Barra de progreso */}
                  {displayVal && (
                    <div>
                      <div style={{
                        height: '4px', borderRadius: '99px',
                        background: 'rgba(255,255,255,0.08)',
                        overflow: 'hidden',
                      }}>
                        <div style={{
                          height: '100%',
                          width: `${progressPct}%`,
                          background: scoreColor,
                          borderRadius: '99px',
                          transition: 'width 0.4s ease',
                        }} />
                      </div>
                      <p style={{ margin: '4px 0 0', fontSize: '10px', color: 'var(--text-muted)', textAlign: 'right' }}>
                        {latestScore.score}/10
                      </p>
                    </div>
                  )}

                  {/* CTA cuando no hay marca */}
                  {!displayVal && (
                    <p style={{ margin: 0, fontSize: '11px', color: 'rgba(249,115,22,0.5)', fontWeight: '700' }}>
                      + Añadir marca
                    </p>
                  )}
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Calculator;
