import React, { useState } from 'react';
import type { UserProfile, Gender } from '../types';
import { oppositions } from '../scoring';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onResetData: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, profile, onUpdateProfile, onResetData }) => {
  const [name, setName]               = useState(profile.name);
  const [gender, setGender]           = useState<Gender>(profile.gender);
  const [oppositionId, setOppositionId] = useState(profile.activeOppositionId);
  const [avatarId, setAvatarId]       = useState(profile.avatarId || '1');
  const [examDate, setExamDate]       = useState(profile.examDate || '');

  if (!isOpen) return null;

  const avatars = [
    { id: '1', icon: '👨‍🚒' }, { id: '2', icon: '👩‍🚒' }, { id: '3', icon: '🚒' },
    { id: '4', icon: '🦁' },  { id: '5', icon: '🦅' },  { id: '6', icon: '⚡' },
  ];

  const handleSave = () => {
    onUpdateProfile({ name, gender, activeOppositionId: oppositionId, avatarId, examDate: examDate || undefined });
    onClose();
  };

  const daysUntilExam = examDate ? (() => {
    const exam = new Date(examDate + 'T12:00:00');
    const now  = new Date(); now.setHours(0,0,0,0);
    const diff = Math.ceil((exam.getTime() - now.getTime()) / 864e5);
    return diff > 0 ? diff : null;
  })() : null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content settings-modal" onClick={e => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}>&times;</button>
        <h2 style={{ fontSize: '22px', fontWeight: '900', color: 'white', marginBottom: '20px', marginTop: '10px' }}>
          Configuración
        </h2>

        {/* Avatar */}
        <div className="form-group">
          <label className="form-label">Avatar</label>
          <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', padding: '8px 2px', scrollbarWidth: 'none' }}
            className="avatar-scroll-container">
            {avatars.map(av => (
              <div key={av.id} onClick={() => setAvatarId(av.id)} style={{
                fontSize: '26px', padding: '10px', minWidth: '52px', textAlign: 'center',
                background: avatarId === av.id ? 'var(--primary)' : 'rgba(255,255,255,0.05)',
                borderRadius: '14px', cursor: 'pointer', flexShrink: 0,
                border: avatarId === av.id ? '2px solid var(--primary)' : '1px solid rgba(255,255,255,0.05)',
                transition: 'all 0.15s',
              }}>
                {av.icon}
              </div>
            ))}
          </div>
        </div>

        {/* Nombre */}
        <div className="form-group">
          <label className="form-label">Nombre</label>
          <input type="text" className="form-input" value={name}
            onChange={e => setName(e.target.value)} placeholder="Tu nombre..." />
        </div>

        {/* Género */}
        <div className="form-group">
          <label className="form-label">Género (baremos)</label>
          <div className="gender-selector">
            <button className={`gender-btn ${gender === 'male' ? 'active' : ''}`} onClick={() => setGender('male')}>Hombre</button>
            <button className={`gender-btn ${gender === 'female' ? 'active' : ''}`} onClick={() => setGender('female')}>Mujer</button>
          </div>
        </div>

        {/* Oposición */}
        <div className="form-group">
          <label className="form-label">Oposición activa</label>
          <select className="form-input" value={oppositionId} onChange={e => setOppositionId(e.target.value)}
            style={{ width: '100%', appearance: 'none', background: '#0f172a url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'24\' height=\'24\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%2394a3b8\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\'%3E%3Cpolyline points=\'6 9 12 15 18 9\'%3E%3C/polyline%3E%3C/svg%3E") no-repeat right 12px center' }}>
            {oppositions.map(opp => (
              <option key={opp.id} value={opp.id}>{opp.name}</option>
            ))}
          </select>
        </div>

        {/* Fecha del examen */}
        <div className="form-group">
          <label className="form-label">Fecha del examen</label>
          <div style={{ position: 'relative' }}>
            <input
              type="date"
              className="form-input"
              value={examDate}
              min={new Date().toISOString().split('T')[0]}
              onChange={e => setExamDate(e.target.value)}
              style={{ color: examDate ? 'var(--primary)' : 'var(--text-muted)', fontWeight: examDate ? '900' : '400' }}
            />
            {daysUntilExam !== null && (
              <div style={{
                marginTop: '6px', padding: '6px 12px',
                background: daysUntilExam < 30 ? 'rgba(239,68,68,0.1)' : 'rgba(249,115,22,0.1)',
                border: `1px solid ${daysUntilExam < 30 ? 'rgba(239,68,68,0.3)' : 'rgba(249,115,22,0.25)'}`,
                borderRadius: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Quedan</span>
                <span style={{ fontSize: '14px', fontWeight: '900', color: daysUntilExam < 30 ? '#ef4444' : 'var(--primary)' }}>
                  {daysUntilExam} días
                </span>
              </div>
            )}
            {examDate && !daysUntilExam && (
              <p style={{ margin: '4px 0 0', fontSize: '11px', color: '#ef4444' }}>
                La fecha de examen ya ha pasado.
              </p>
            )}
          </div>
        </div>

        {/* Zona de peligro */}
        <div className="form-group" style={{ marginTop: '8px' }}>
          <label className="form-label" style={{ color: '#ef4444' }}>Zona de peligro</label>
          <button className="reset-data-btn" onClick={onResetData}
            style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444', border: '1px solid rgba(239,68,68,0.3)', fontWeight: '900' }}>
            Borrar todos los datos
          </button>
        </div>

        <footer className="modal-footer" style={{ marginTop: '16px' }}>
          <button className="save-btn" onClick={handleSave}>Guardar cambios</button>
        </footer>
      </div>
    </div>
  );
};

export default SettingsModal;
