import React, { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Haptics, NotificationType, ImpactStyle } from '@capacitor/haptics';
import { exerciseLibrary } from '../data/exerciseLibrary';
import type { UserProfile } from '../types';

// ── Tipos ────────────────────────────────────────────────────────────────────
interface Exercise {
  name: string;
  target: string;
  sets?: number;
  reps_or_time?: string;
  rest?: string;
  coach_tip?: string;
  completed: boolean;
}

interface Workout {
  dayName: string;
  title: string;
  type?: 'rest' | 'athletics' | 'strength' | 'swimming' | 'active_recovery';
  warmup?: string[];
  exercises: Exercise[];
}

interface TrainingProps {
  history: any[];
  profile: UserProfile;
  onSaveWorkout: (title: string, rpe?: number, notes?: string, exercises?: any[]) => void;
  onStartDiagnostic: () => void;
}

// ── Constantes visuales ───────────────────────────────────────────────────────
const TYPE_COLOR: Record<string, string> = {
  rest: '#94a3b8', active_recovery: '#94a3b8',
  strength: '#f97316', athletics: '#38bdf8', swimming: '#22c55e',
};
const TYPE_EMOJI: Record<string, string> = {
  rest: '😴', active_recovery: '🧘', strength: '💪', athletics: '🏃', swimming: '🏊',
};
const TYPE_LABEL: Record<string, string> = {
  rest: 'Descanso', active_recovery: 'Recuperación',
  strength: 'Fuerza', athletics: 'Atletismo', swimming: 'Natación',
};
const PHASE_LABEL: Record<string, string> = {
  base: 'Fase de base', transformation: 'Transformación',
  realization: 'Realización', tapering: 'Taper · Puesta a punto',
};

// ── Plan estático de fallback ─────────────────────────────────────────────────
const FALLBACK: Record<number, Workout> = {
  0: { dayName: 'Domingo',   title: 'Descanso Activo / Movilidad', type: 'rest',
       exercises: [{ name: 'Caminata ligera', target: '30 min', completed: false },
                   { name: 'Estiramientos estáticos', target: '15 min', completed: false },
                   { name: 'Recuperación y sueño', target: 'Prioritario', completed: false }] },
  1: { dayName: 'Lunes',     title: 'Fuerza: Tren Superior', type: 'strength',
       warmup: ['Movilidad de hombros 5 min', 'Activación escapular'],
       exercises: [{ name: 'Press Banca', target: '4 x 10 reps (70% RM)', sets: 4, reps_or_time: '10 reps', rest: '90s', completed: false },
                   { name: 'Dominadas',   target: '4 x fallo técnico',    sets: 4, reps_or_time: 'Fallo técnico', rest: '2 min', completed: false },
                   { name: 'Press Militar', target: '3 x 12 reps',        sets: 3, reps_or_time: '12 reps', rest: '90s', completed: false },
                   { name: 'Core: Plancha', target: '3 x 1 min',          sets: 3, reps_or_time: '1 min', completed: false }] },
  2: { dayName: 'Martes',    title: 'Resistencia: Series 1000m', type: 'athletics',
       warmup: ['Trote suave 10 min', 'Progresivos 4 x 80m'],
       exercises: [{ name: 'Series 1000m', target: '5 x 1000m @ 3:50', sets: 5, reps_or_time: '1000m', rest: '90s', completed: false },
                   { name: 'Vuelta a la calma', target: '10 min trote suave', completed: false }] },
  3: { dayName: 'Miércoles', title: 'Técnica de Oposición', type: 'strength',
       warmup: ['Movilidad articular 8 min'],
       exercises: [{ name: 'Subida de Cuerda', target: '6 subidas explosivas', sets: 6, reps_or_time: '1 subida', rest: '2 min', coach_tip: 'Salida sentado, brazos solos', completed: false },
                   { name: 'Press Banca',      target: '4 x 10 reps',         sets: 4, reps_or_time: '10 reps', rest: '90s', completed: false },
                   { name: 'Torre',            target: '3 subidas completas',  sets: 3, reps_or_time: '1 subida', rest: '3 min', completed: false }] },
  4: { dayName: 'Jueves',    title: 'Natación: Específico', type: 'swimming',
       warmup: ['Movilidad articular 10 min'],
       exercises: [{ name: 'Natación: 50m Crol', target: '4 series @ 100%', sets: 4, reps_or_time: '50m', rest: '2 min', coach_tip: 'Simula el día del examen', completed: false },
                   { name: 'Técnica de virajes', target: '15 min',           completed: false }] },
  5: { dayName: 'Viernes',   title: 'Carrera Continua / HIIT', type: 'athletics',
       warmup: ['Trote suave 8 min', 'Estiramientos dinámicos'],
       exercises: [{ name: 'Carrera Continua (Zona 2)', target: '40 min', completed: false },
                   { name: 'Sprints en cuesta', target: '10 x 50m', sets: 10, reps_or_time: '50m', rest: '45s', completed: false },
                   { name: 'Core explosivo',    target: '3 series', sets: 3, completed: false }] },
  6: { dayName: 'Sábado',    title: 'Simulacro / Combinado', type: 'athletics',
       exercises: [{ name: 'Simulacro Natación 50m', target: 'Paso 1', completed: false },
                   { name: 'Simulacro Cuerda',       target: 'Paso 2', completed: false },
                   { name: 'Simulacro Carrera 3000m', target: 'Paso 3', completed: false }] },
};

// ── Helpers ───────────────────────────────────────────────────────────────────
const sessionEmoji = (title: string, type?: string): string => {
  if (type) return TYPE_EMOJI[type] ?? '📋';
  const t = title.toLowerCase();
  if (t.includes('natac') || t.includes('piscina')) return '🏊';
  if (t.includes('fuerza') || t.includes('press') || t.includes('cuerda')) return '💪';
  if (t.includes('carrera') || t.includes('3000') || t.includes('1000') || t.includes('60m')) return '🏃';
  if (t.includes('descanso') || t.includes('movilidad')) return '😴';
  if (t.includes('simulacro')) return '🎯';
  return '📋';
};

const rpeColor = (r: number) =>
  r <= 4 ? '#22c55e' : r <= 6 ? '#f97316' : r <= 8 ? '#f59e0b' : '#ef4444';

const rpeLabel = (r: number) =>
  r <= 3 ? 'Muy suave' : r <= 5 ? 'Moderado' : r <= 7 ? 'Duro' : r <= 9 ? 'Muy duro' : 'Máximo';

// ─────────────────────────────────────────────────────────────────────────────
const Training: React.FC<TrainingProps> = ({ history, profile, onSaveWorkout, onStartDiagnostic }) => {
  const today = new Date().getDay();

  const [activeTab, setActiveTab]           = useState<'plan' | 'hist'>('plan');
  const [selectedDay, setSelectedDay]       = useState<number>(today);
  const [filterType, setFilterType]         = useState<string>('all');
  const [showRpeModal, setShowRpeModal]     = useState(false);
  const [rpe, setRpe]                       = useState<number>(7);
  const [notes, setNotes]                   = useState('');
  const [selectedSession, setSelectedSession] = useState<any | null>(null);
  const [selectedExercise, setSelectedExercise] = useState<any | null>(null);

  // Estado local de ejercicios completados (por día) — evita mutar el plan
  const [completedMap, setCompletedMap] = useState<Record<string, boolean>>({});

  const isPlanConfigured = !!profile.physicalData && !!profile.availability;

  const days = [
    { id: 1, label: 'L' }, { id: 2, label: 'M' }, { id: 3, label: 'X' },
    { id: 4, label: 'J' }, { id: 5, label: 'V' }, { id: 6, label: 'S' },
    { id: 0, label: 'D' },
  ];

  // Workout del día seleccionado (plan IA o fallback)
  const baseWorkout: Workout =
    profile.trainingPlan?.weeklySchedule?.[selectedDay] || FALLBACK[selectedDay];

  // Ejercicios con estado local de completado
  const exercises: Exercise[] = useMemo(() =>
    baseWorkout.exercises.map((ex, i) => ({
      ...ex,
      completed: completedMap[`${selectedDay}_${i}`] ?? false,
    })),
    [baseWorkout, completedMap, selectedDay]
  );

  const completedCount = exercises.filter(e => e.completed).length;
  const totalCount     = exercises.length;
  const progressPct    = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;
  const wodColor       = TYPE_COLOR[baseWorkout.type ?? 'athletics'] ?? '#f97316';

  const toggleExercise = useCallback((index: number) => {
    const key = `${selectedDay}_${index}`;
    setCompletedMap(prev => ({ ...prev, [key]: !prev[key] }));
    Haptics.impact({ style: ImpactStyle.Light });
  }, [selectedDay]);

  // Historial filtrado
  const filteredHistory = useMemo(() => {
    const workouts = history.filter(h => h.type === 'workout')
      .sort((a, b) => b.timestamp - a.timestamp);
    if (filterType === 'all') return workouts;
    return workouts.filter(s => {
      const t = (s.workoutTitle || '').toLowerCase();
      const exs = (s.exercises || []).map((e: any) => e.name.toLowerCase());
      if (filterType === 'strength')
        return t.includes('fuerza') || t.includes('press') || t.includes('cuerda') ||
               exs.some((e: string) => e.includes('press') || e.includes('dominada') || e.includes('cuerda'));
      if (filterType === 'athletics')
        return t.includes('carrera') || t.includes('3000') || t.includes('1000') || t.includes('60m') || t.includes('sprint') ||
               exs.some((e: string) => e.includes('carrera') || e.includes('3000') || e.includes('sprint'));
      if (filterType === 'swimming')
        return t.includes('natac') || t.includes('piscina') ||
               exs.some((e: string) => e.includes('natac') || e.includes('crol'));
      return true;
    });
  }, [history, filterType]);

  const handleCompleteWorkout = () => setShowRpeModal(true);

  const confirmCompleteWorkout = () => {
    onSaveWorkout(baseWorkout.title, rpe, notes, exercises);
    setShowRpeModal(false);
    setActiveTab('hist');
    setNotes('');
    setRpe(7);
    // Reset completados para este día
    setCompletedMap(prev => {
      const next = { ...prev };
      exercises.forEach((_, i) => delete next[`${selectedDay}_${i}`]);
      return next;
    });
    Haptics.notification({ type: NotificationType.Success });
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="page-content">
      <main className="main" style={{
        paddingTop: 'calc(16px + env(safe-area-inset-top))',
        paddingBottom: '120px',
      }}>

        {/* TABS */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '32px', marginBottom: '24px' }}>
          {(['plan', 'hist'] as const).map(tab => (
            <div key={tab} onClick={() => setActiveTab(tab)} style={{ cursor: 'pointer', position: 'relative', paddingBottom: '8px' }}>
              <span style={{
                fontSize: '17px', fontWeight: '800',
                color: activeTab === tab ? 'white' : 'rgba(255,255,255,0.25)',
                transition: 'color 0.2s',
              }}>
                {tab === 'plan' ? 'Plan' : 'Historial'}
              </span>
              {activeTab === tab && (
                <motion.div layoutId="tabLine" style={{
                  position: 'absolute', bottom: 0, left: 0, right: 0,
                  height: '3px', background: 'var(--primary)', borderRadius: '2px',
                }} />
              )}
            </div>
          ))}
        </div>

        {/* ══════════════════════════════════════════
            TAB: PLAN
        ══════════════════════════════════════════ */}
        {activeTab === 'plan' && (
          <div>
            {!isPlanConfigured ? (
              /* Estado: sin plan configurado */
              <div style={{
                textAlign: 'center', padding: '40px 20px',
                background: 'rgba(255,255,255,0.03)',
                borderRadius: '24px', border: '1px dashed rgba(255,255,255,0.1)',
              }}>
                <div style={{ fontSize: '50px', marginBottom: '16px' }}>🎯</div>
                <h2 style={{ fontSize: '18px', fontWeight: '900', color: 'white', marginBottom: '8px' }}>Plan no configurado</h2>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginBottom: '24px', lineHeight: 1.5 }}>
                  Completa el diagnóstico para generar un plan adaptado a tus debilidades y disponibilidad.
                </p>
                <button onClick={onStartDiagnostic} style={{
                  background: 'var(--primary)', color: 'black', border: 'none',
                  borderRadius: '12px', padding: '14px 24px',
                  fontSize: '14px', fontWeight: '900', cursor: 'pointer',
                }}>
                  Configurar plan IA
                </button>
              </div>
            ) : (
              <>
                {/* Selector de día */}
                <div style={{ marginBottom: '20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                    <span style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px' }}>
                      {profile.trainingPlan ? PHASE_LABEL[profile.trainingPlan.phase] ?? 'Plan semanal' : 'Plan semanal'}
                    </span>
                    <button onClick={onStartDiagnostic} style={{
                      background: 'none', border: 'none',
                      color: 'var(--primary)', fontSize: '11px', fontWeight: '800', cursor: 'pointer',
                    }}>
                      Reconfigurar ⚙️
                    </button>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: '6px' }}>
                    {days.map(day => {
                      const isToday    = day.id === today;
                      const isSelected = day.id === selectedDay;
                      const dayWorkout = profile.trainingPlan?.weeklySchedule?.[day.id] || FALLBACK[day.id];
                      const dotColor   = TYPE_COLOR[dayWorkout.type ?? 'athletics'];
                      return (
                        <div key={day.id} onClick={() => setSelectedDay(day.id)} style={{
                          flex: 1, display: 'flex', flexDirection: 'column',
                          alignItems: 'center', gap: '4px', cursor: 'pointer',
                        }}>
                          <div style={{
                            width: '100%', aspectRatio: '1',
                            borderRadius: '12px',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontWeight: '900', fontSize: '14px',
                            background: isSelected ? 'var(--primary)' : isToday ? 'rgba(249,115,22,0.12)' : 'rgba(255,255,255,0.05)',
                            color: isSelected ? 'black' : isToday ? 'var(--primary)' : 'white',
                            border: isToday && !isSelected ? '1px solid rgba(249,115,22,0.4)' : '1px solid transparent',
                            transition: 'all 0.15s',
                          }}>
                            {day.label}
                          </div>
                          {/* Punto de color por tipo */}
                          <div style={{
                            width: '5px', height: '5px', borderRadius: '50%',
                            background: isSelected ? 'var(--primary)' : dotColor,
                            opacity: isSelected ? 1 : 0.5,
                          }} />
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Card del entrenamiento */}
                <section style={{
                  background: `linear-gradient(135deg, ${wodColor}12 0%, rgba(30,41,59,0.5) 100%)`,
                  border: `1px solid ${wodColor}30`,
                  borderRadius: '20px', padding: '20px', marginBottom: '12px',
                }}>
                  {/* Cabecera */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                        <span style={{ fontSize: '11px', fontWeight: '900', color: wodColor, textTransform: 'uppercase', letterSpacing: '1px' }}>
                          {TYPE_LABEL[baseWorkout.type ?? 'athletics']} · {baseWorkout.dayName}
                        </span>
                      </div>
                      {profile.trainingPlan?.weeklyFocus && (
                        <p style={{ margin: '0 0 6px', fontSize: '11px', color: 'rgba(255,255,255,0.35)', fontStyle: 'italic' }}>
                          "{profile.trainingPlan.weeklyFocus}"
                        </p>
                      )}
                      <p style={{ margin: 0, fontSize: '20px', fontWeight: '900', color: 'white' }}>
                        {baseWorkout.title}
                      </p>
                    </div>
                    <span style={{ fontSize: '32px', marginLeft: '12px' }}>
                      {TYPE_EMOJI[baseWorkout.type ?? 'athletics'] ?? '📋'}
                    </span>
                  </div>

                  {/* Barra de progreso */}
                  <div style={{ marginBottom: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                      <span style={{ fontSize: '10px', color: 'var(--text-muted)', fontWeight: '700', textTransform: 'uppercase' }}>
                        Progreso
                      </span>
                      <span style={{ fontSize: '11px', fontWeight: '900', color: completedCount === totalCount && totalCount > 0 ? '#22c55e' : wodColor }}>
                        {completedCount}/{totalCount}
                      </span>
                    </div>
                    <div style={{ height: '5px', borderRadius: '99px', background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                      <motion.div
                        animate={{ width: `${progressPct}%` }}
                        transition={{ duration: 0.3 }}
                        style={{
                          height: '100%', borderRadius: '99px',
                          background: completedCount === totalCount && totalCount > 0 ? '#22c55e' : wodColor,
                        }}
                      />
                    </div>
                  </div>

                  {/* Calentamiento */}
                  {baseWorkout.warmup && baseWorkout.warmup.length > 0 && (
                    <div style={{
                      marginBottom: '14px', padding: '12px 14px',
                      background: 'rgba(255,255,255,0.03)',
                      borderRadius: '14px', border: '1px dashed rgba(255,255,255,0.08)',
                    }}>
                      <span style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '8px' }}>
                        🔥 Calentamiento
                      </span>
                      {baseWorkout.warmup.map((w, i) => (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: i < baseWorkout.warmup!.length - 1 ? '4px' : 0 }}>
                          <div style={{ width: '4px', height: '4px', borderRadius: '50%', background: wodColor, flexShrink: 0 }} />
                          <span style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)' }}>{w}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Ejercicios */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {exercises.map((ex, i) => {
                      const libInfo = exerciseLibrary[ex.name];
                      return (
                        <div
                          key={i}
                          style={{
                            display: 'flex', alignItems: 'center', gap: '12px',
                            padding: '14px 14px',
                            background: ex.completed ? `${wodColor}10` : 'rgba(255,255,255,0.03)',
                            borderRadius: '14px',
                            border: `1px solid ${ex.completed ? wodColor + '30' : 'rgba(255,255,255,0.04)'}`,
                            opacity: ex.completed ? 0.7 : 1,
                            transition: 'all 0.2s',
                          }}
                        >
                          {/* Checkbox */}
                          <div
                            onClick={() => toggleExercise(i)}
                            style={{
                              width: '26px', height: '26px', borderRadius: '8px', flexShrink: 0,
                              border: ex.completed ? 'none' : '2px solid rgba(255,255,255,0.2)',
                              background: ex.completed ? 'var(--primary)' : 'transparent',
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              cursor: 'pointer', transition: 'all 0.15s',
                            }}
                          >
                            {ex.completed && <span style={{ color: 'black', fontSize: '13px', fontWeight: '900' }}>✓</span>}
                          </div>

                          {/* Info */}
                          <div
                            style={{ flex: 1, cursor: libInfo ? 'pointer' : 'default' }}
                            onClick={() => libInfo && setSelectedExercise({ ...libInfo, ...ex })}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                              <span style={{
                                fontSize: '14px', fontWeight: '800', color: 'white',
                                textDecoration: ex.completed ? 'line-through' : 'none',
                              }}>
                                {ex.name}
                              </span>
                              {ex.coach_tip && <span style={{ fontSize: '12px' }}>💡</span>}
                              {libInfo && <span style={{ fontSize: '10px', color: 'rgba(255,255,255,0.25)' }}>ⓘ</span>}
                            </div>
                            <div style={{ display: 'flex', gap: '8px', marginTop: '3px', flexWrap: 'wrap' }}>
                              {ex.sets && (
                                <span style={{ fontSize: '11px', color: wodColor, fontWeight: '900' }}>
                                  {ex.sets} series
                                </span>
                              )}
                              <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                                {ex.reps_or_time || ex.target}
                              </span>
                              {ex.rest && (
                                <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.2)' }}>
                                  · {ex.rest} desc.
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Botón finalizar */}
                  <button
                    onClick={handleCompleteWorkout}
                    style={{
                      width: '100%', marginTop: '20px', padding: '16px',
                      borderRadius: '14px', border: 'none',
                      background: completedCount === totalCount && totalCount > 0
                        ? '#22c55e' : 'var(--primary)',
                      color: 'black', fontWeight: '900', fontSize: '15px',
                      cursor: 'pointer', transition: 'background 0.3s',
                      opacity: completedCount === 0 ? 0.6 : 1,
                    }}
                  >
                    {completedCount === 0
                      ? 'Finalizar entrenamiento'
                      : completedCount === totalCount
                      ? '✓ ¡Completado! Guardar sesión'
                      : `Finalizar (${completedCount}/${totalCount} ejercicios)`}
                  </button>
                </section>
              </>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════
            TAB: HISTORIAL
        ══════════════════════════════════════════ */}
        {activeTab === 'hist' && (
          <div>
            {/* Filtros */}
            <div className="test-selector-scroll" style={{ marginBottom: '16px' }}>
              {[
                { id: 'all',       label: 'Todo' },
                { id: 'strength',  label: '💪 Fuerza' },
                { id: 'athletics', label: '🏃 Carrera' },
                { id: 'swimming',  label: '🏊 Natación' },
              ].map(f => (
                <button key={f.id} onClick={() => setFilterType(f.id)} className={filterType === f.id ? 'active' : ''}>
                  {f.label}
                </button>
              ))}
            </div>

            {/* Lista */}
            {filteredHistory.length === 0 ? (
              <div style={{
                textAlign: 'center', padding: '48px 24px',
                background: 'rgba(255,255,255,0.02)',
                borderRadius: '20px', border: '1px dashed rgba(255,255,255,0.08)',
              }}>
                <p style={{ fontSize: '40px', marginBottom: '12px' }}>🏋️</p>
                <p style={{ fontSize: '14px', color: 'var(--text-muted)' }}>
                  {filterType === 'all'
                    ? 'Aún no has completado ningún entrenamiento. ¡A por ello!'
                    : 'No hay sesiones de este tipo registradas.'}
                </p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {filteredHistory.map((session, i) => (
                  <div
                    key={i}
                    onClick={() => setSelectedSession(session)}
                    style={{
                      background: 'var(--card-bg)',
                      padding: '14px 16px', borderRadius: '18px',
                      border: '1px solid rgba(255,255,255,0.05)',
                      display: 'flex', alignItems: 'center', gap: '14px',
                      cursor: 'pointer',
                    }}
                  >
                    {/* Icono */}
                    <div style={{
                      width: '44px', height: '44px', borderRadius: '12px', flexShrink: 0,
                      background: 'rgba(255,255,255,0.04)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: '20px',
                    }}>
                      {sessionEmoji(session.workoutTitle || '', session.exercises?.[0]?.type)}
                    </div>

                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ margin: 0, fontSize: '14px', fontWeight: '800', color: 'white', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {session.workoutTitle || 'Entrenamiento'}
                      </p>
                      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginTop: '3px' }}>
                        <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                          {new Date(session.timestamp).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' })}
                        </span>
                        {session.rpe && (
                          <span style={{
                            fontSize: '10px', fontWeight: '900',
                            color: rpeColor(session.rpe),
                            background: rpeColor(session.rpe) + '20',
                            padding: '1px 7px', borderRadius: '6px',
                          }}>
                            RPE {session.rpe}
                          </span>
                        )}
                      </div>
                    </div>

                    <span style={{ fontSize: '14px', color: 'rgba(255,255,255,0.2)', flexShrink: 0 }}>›</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════
            MODAL: FICHA DE EJERCICIO
        ══════════════════════════════════════════ */}
        <AnimatePresence>
          {selectedExercise && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              style={{
                position: 'fixed', inset: 0,
                backgroundColor: 'rgba(0,0,0,0.92)',
                zIndex: 3000, display: 'flex', alignItems: 'flex-end',
              }}
              onClick={() => setSelectedExercise(null)}
            >
              <motion.div
                initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
                transition={{ type: 'spring', damping: 28, stiffness: 300 }}
                onClick={e => e.stopPropagation()}
                style={{
                  width: '100%', maxHeight: '85vh', overflowY: 'auto',
                  background: '#111827', borderRadius: '28px 28px 0 0',
                  padding: '28px 24px 40px',
                  border: '1px solid rgba(255,255,255,0.08)',
                }}
              >
                {/* Handle */}
                <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'rgba(255,255,255,0.15)', margin: '0 auto 20px' }} />

                <span style={{ fontSize: '10px', color: 'var(--primary)', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '1px' }}>
                  {selectedExercise.category || 'Ejercicio'}
                </span>
                <h2 style={{ fontSize: '24px', fontWeight: '900', color: 'white', margin: '4px 0 8px' }}>
                  {selectedExercise.name}
                </h2>
                <p style={{ fontSize: '15px', color: 'var(--primary)', fontWeight: '800', margin: '0 0 16px' }}>
                  {selectedExercise.sets ? `${selectedExercise.sets} series × ` : ''}
                  {selectedExercise.reps_or_time || selectedExercise.target}
                  {selectedExercise.rest ? ` · ${selectedExercise.rest} desc.` : ''}
                </p>

                {selectedExercise.coach_tip && (
                  <div style={{ marginBottom: '18px', padding: '14px', background: 'rgba(249,115,22,0.07)', borderRadius: '14px', border: '1px solid rgba(249,115,22,0.2)' }}>
                    <p style={{ margin: 0, fontSize: '10px', color: 'var(--primary)', fontWeight: '900', textTransform: 'uppercase', marginBottom: '6px' }}>💡 Coach tip</p>
                    <p style={{ margin: 0, fontSize: '13px', color: 'white', fontStyle: 'italic', lineHeight: 1.5 }}>"{selectedExercise.coach_tip}"</p>
                  </div>
                )}

                {selectedExercise.description && (
                  <div style={{ marginBottom: '18px' }}>
                    <p style={{ margin: '0 0 6px', fontSize: '10px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>Ejecución</p>
                    <p style={{ margin: 0, fontSize: '14px', color: 'white', lineHeight: 1.6 }}>{selectedExercise.description}</p>
                  </div>
                )}

                {selectedExercise.tips && (
                  <div style={{ marginBottom: '24px' }}>
                    <p style={{ margin: '0 0 10px', fontSize: '10px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>Consejos clave</p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {selectedExercise.tips.map((tip: string, idx: number) => (
                        <div key={idx} style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                          <span style={{ color: 'var(--primary)', fontSize: '14px', flexShrink: 0, marginTop: '1px' }}>›</span>
                          <span style={{ fontSize: '13px', color: 'rgba(255,255,255,0.85)', lineHeight: 1.4 }}>{tip}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div style={{ display: 'flex', gap: '10px' }}>
                  {selectedExercise.videoUrl && (
                    <a href={selectedExercise.videoUrl} target="_blank" rel="noopener noreferrer"
                      style={{ flex: 1, padding: '14px', borderRadius: '14px', background: 'rgba(255,255,255,0.05)', color: 'white', fontWeight: '900', textAlign: 'center', textDecoration: 'none', fontSize: '13px', border: '1px solid rgba(255,255,255,0.1)' }}>
                      📺 Ver vídeo
                    </a>
                  )}
                  <button onClick={() => setSelectedExercise(null)}
                    style={{ flex: 1, padding: '14px', borderRadius: '14px', background: 'var(--primary)', border: 'none', color: 'black', fontWeight: '900', fontSize: '13px', cursor: 'pointer' }}>
                    Entendido
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ══════════════════════════════════════════
            MODAL: DETALLE SESIÓN (bottom sheet)
        ══════════════════════════════════════════ */}
        <AnimatePresence>
          {selectedSession && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', zIndex: 2000, display: 'flex', alignItems: 'flex-end' }}
              onClick={() => setSelectedSession(null)}
            >
              <motion.div
                initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 100, opacity: 0 }}
                transition={{ type: 'spring', damping: 28, stiffness: 300 }}
                onClick={e => e.stopPropagation()}
                style={{
                  width: '100%', maxHeight: '80vh', overflowY: 'auto',
                  background: '#111827', borderRadius: '28px 28px 0 0',
                  padding: '28px 24px 40px',
                  border: '1px solid rgba(255,255,255,0.08)',
                }}
              >
                <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'rgba(255,255,255,0.15)', margin: '0 auto 20px' }} />

                <p style={{ margin: '0 0 4px', fontSize: '11px', color: 'var(--primary)', fontWeight: '900', textTransform: 'uppercase' }}>
                  {new Date(selectedSession.timestamp).toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
                </p>
                <h2 style={{ margin: '0 0 18px', fontSize: '22px', fontWeight: '900', color: 'white' }}>
                  {selectedSession.workoutTitle || 'Entrenamiento'}
                </h2>

                {/* Stats */}
                <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
                  {selectedSession.rpe && (
                    <div style={{ flex: 1, padding: '12px', background: rpeColor(selectedSession.rpe) + '15', borderRadius: '14px', textAlign: 'center', border: `1px solid ${rpeColor(selectedSession.rpe)}30` }}>
                      <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>Esfuerzo</p>
                      <p style={{ margin: '4px 0 0', fontSize: '22px', fontWeight: '900', color: rpeColor(selectedSession.rpe) }}>{selectedSession.rpe}/10</p>
                      <p style={{ margin: '2px 0 0', fontSize: '10px', color: 'var(--text-muted)' }}>{rpeLabel(selectedSession.rpe)}</p>
                    </div>
                  )}
                  <div style={{ flex: 1, padding: '12px', background: 'rgba(34,197,94,0.1)', borderRadius: '14px', textAlign: 'center', border: '1px solid rgba(34,197,94,0.2)' }}>
                    <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>Estado</p>
                    <p style={{ margin: '4px 0 0', fontSize: '16px', fontWeight: '900', color: '#22c55e' }}>✓ Completado</p>
                  </div>
                </div>

                {/* Notas */}
                {selectedSession.notes && (
                  <div style={{ marginBottom: '18px', padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.06)' }}>
                    <p style={{ margin: '0 0 6px', fontSize: '9px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>Notas</p>
                    <p style={{ margin: 0, fontSize: '13px', color: 'white', lineHeight: 1.5, fontStyle: 'italic' }}>"{selectedSession.notes}"</p>
                  </div>
                )}

                {/* Ejercicios */}
                {selectedSession.exercises?.length > 0 && (
                  <div>
                    <p style={{ margin: '0 0 10px', fontSize: '9px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>
                      Ejercicios · {selectedSession.exercises.length}
                    </p>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      {selectedSession.exercises.map((ex: any, idx: number) => (
                        <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: '10px' }}>
                          <span style={{ fontSize: '13px', color: ex.completed ? '#22c55e' : 'rgba(255,255,255,0.2)' }}>
                            {ex.completed ? '✓' : '○'}
                          </span>
                          <div>
                            <p style={{ margin: 0, fontSize: '13px', fontWeight: '700', color: 'white' }}>{ex.name}</p>
                            <p style={{ margin: 0, fontSize: '11px', color: 'var(--text-muted)' }}>{ex.target}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ══════════════════════════════════════════
            MODAL: RPE al finalizar
        ══════════════════════════════════════════ */}
        <AnimatePresence>
          {showRpeModal && (
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.88)', display: 'flex', alignItems: 'flex-end', zIndex: 4000 }}
            >
              <motion.div
                initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
                transition={{ type: 'spring', damping: 28, stiffness: 300 }}
                style={{
                  width: '100%', background: '#111827',
                  borderRadius: '28px 28px 0 0', padding: '28px 24px 44px',
                  border: '1px solid rgba(255,255,255,0.08)',
                }}
              >
                <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'rgba(255,255,255,0.15)', margin: '0 auto 20px' }} />

                <h2 style={{ fontSize: '20px', fontWeight: '900', color: 'white', textAlign: 'center', marginBottom: '6px' }}>
                  ¿Cómo ha ido?
                </h2>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)', textAlign: 'center', marginBottom: '28px' }}>
                  Tu feedback mejora el plan de la próxima semana.
                </p>

                {/* RPE slider */}
                <div style={{ marginBottom: '28px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                    <span style={{ fontSize: '12px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Esfuerzo percibido</span>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: '6px' }}>
                      <span style={{ fontSize: '22px', fontWeight: '900', color: rpeColor(rpe) }}>{rpe}</span>
                      <span style={{ fontSize: '11px', color: rpeColor(rpe) }}>{rpeLabel(rpe)}</span>
                    </div>
                  </div>
                  <input type="range" min="1" max="10" step="1" value={rpe}
                    onChange={e => setRpe(parseInt(e.target.value))}
                    style={{ width: '100%', accentColor: rpeColor(rpe) }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '6px', fontSize: '10px', color: 'rgba(255,255,255,0.2)', fontWeight: '700' }}>
                    <span>1 · Suave</span>
                    <span>5 · Moderado</span>
                    <span>10 · Máximo</span>
                  </div>
                </div>

                {/* Notas */}
                <div style={{ marginBottom: '24px' }}>
                  <label style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', display: 'block', marginBottom: '8px' }}>
                    Notas (opcional)
                  </label>
                  <textarea value={notes} onChange={e => setNotes(e.target.value)}
                    placeholder="Molestias, sensaciones, pesos usados..."
                    style={{
                      width: '100%', background: 'rgba(255,255,255,0.04)',
                      border: '1px solid rgba(255,255,255,0.1)', borderRadius: '14px',
                      padding: '12px 14px', color: 'white', fontSize: '14px',
                      fontFamily: 'inherit', minHeight: '72px', resize: 'none',
                    }}
                  />
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button onClick={() => setShowRpeModal(false)}
                    style={{ flex: 1, padding: '15px', borderRadius: '14px', background: 'rgba(255,255,255,0.05)', border: 'none', color: 'white', fontWeight: '800', fontSize: '14px', cursor: 'pointer' }}>
                    Cancelar
                  </button>
                  <button onClick={confirmCompleteWorkout}
                    style={{ flex: 2, padding: '15px', borderRadius: '14px', background: 'var(--primary)', border: 'none', color: 'black', fontWeight: '900', fontSize: '14px', cursor: 'pointer' }}>
                    Guardar sesión
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </main>
    </div>
  );
};

export default Training;
