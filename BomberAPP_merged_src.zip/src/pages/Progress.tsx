import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip
} from 'recharts';
import { achievements } from '../data/achievements';
import type { SessionRecord, UserProfile, TestScore, TimeRange } from '../types';
import { tests, oppositions, allScoringCriteria, parseValue } from '../scoring';

interface ProgressProps {
  history: SessionRecord[];
  profile: UserProfile;
  currentStats: TestScore[];
  onDeleteRecord?: (id: string, testName: string) => void;
  onUpdateRecord?: (id: string, testName: string, newValue: string) => void;
}

const testEmoji: Record<string, string> = {
  'Cuerda': '🪢', '3000m': '🏃', '60m': '⚡',
  'Natacion': '🏊', 'Press Banca': '🏋️', 'Torre': '🏗️',
};

const getScoreColor = (score: number): string => {
  if (score === 0)  return '#ef4444';
  if (score >= 9)   return '#22c55e';
  if (score >= 7)   return '#f97316';
  return '#f59e0b';
};

type Tab = 'general' | 'detailed' | 'records' | 'achievements';

const Progress: React.FC<ProgressProps> = ({ history, profile, currentStats }) => {
  const [activeTab, setActiveTab]       = useState<Tab>('general');
  const [selectedTest, setSelectedTest] = useState<string>(tests[0].name);
  const [timeRange, setTimeRange]       = useState<TimeRange>('all');
  const [activeRadarData, setActiveRadarData] = useState<any>(null);

  const unlockedCount = useMemo(
    () => achievements.filter(a => profile.achievements?.includes(a.id)).length,
    [profile.achievements]
  );

  // ── Historial filtrado (solo marcas) ──────────────────────────────────────
  const filteredHistory = useMemo(() => {
    const marks = history.filter(h => h.type === 'mark');
    if (timeRange === 'all') return marks;
    const now = Date.now();
    const ms: Record<string, number> = {
      '30d': 30 * 864e5, '3m': 90 * 864e5, '1y': 365 * 864e5,
    };
    return marks.filter(h => now - h.timestamp <= (ms[timeRange] ?? Infinity));
  }, [history, timeRange]);

  // ── Datos radar ───────────────────────────────────────────────────────────
  const radarData = useMemo(() =>
    tests.map(t => {
      const stat = currentStats.find(s => s.name === t.name);
      return {
        subject: t.name === 'Natacion' ? 'Natación' :
                 t.name === 'Press Banca' ? 'Banca' : t.name,
        fullSubject: t.name,
        A: stat?.score ?? 0,
        value: stat?.value ?? '---',
        fullMark: 10,
      };
    }), [currentStats]);

  // ── Datos gráfico de detalle ──────────────────────────────────────────────
  const testCriteria = useMemo(() => {
    const opp = oppositions.find(o => o.id === profile.activeOppositionId) || oppositions[0];
    return allScoringCriteria[opp.scoringTable][selectedTest];
  }, [selectedTest, profile.activeOppositionId]);

  const testHistoryData = useMemo(() => {
    return [...filteredHistory].reverse().map(session => {
      const ts = session.scores.find(s => s.name === selectedTest);
      const nv = ts ? parseValue(ts.value, testCriteria?.unit || 'seconds') : null;
      return {
        dateLabel: new Date(session.timestamp).toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' }),
        points: ts?.score ?? null,
        value: ts?.value ?? null,
        numericValue: nv,
      };
    }).filter(d => d.numericValue !== null && !isNaN(d.numericValue as number));
  }, [filteredHistory, selectedTest, testCriteria]);

  const formatYAxis = (val: number) => {
    if (testCriteria?.unit === 'time' || testCriteria?.unit === 'towerTime') {
      const m = Math.floor(val / 60);
      const s = Math.floor(val % 60);
      return m > 0 ? `${m}:${s.toString().padStart(2, '0')}` : `${s}s`;
    }
    return String(val);
  };

  // ── Insight detallado mejorado ────────────────────────────────────────────
  const insight = useMemo(() => {
    if (testHistoryData.length < 2)
      return { text: 'Registra al menos 2 sesiones para ver tu tendencia en esta prueba.', color: 'var(--text-muted)' };

    const scores = testHistoryData.map(d => d.points as number).filter(Boolean);
    const latest = scores[scores.length - 1];
    const prev   = scores[scores.length - 2];
    const diff   = latest - prev;
    const trend  = scores.slice(-4);
    const improving = trend.every((v, i) => i === 0 || v >= trend[i - 1]);
    const declining  = trend.every((v, i) => i === 0 || v <= trend[i - 1]);

    if (latest === 0)
      return { text: `Estás por debajo del mínimo eliminatorio. Prioriza esta prueba de inmediato.`, color: '#ef4444' };
    if (latest >= 10)
      return { text: `Puntuación máxima. Mantén el nivel y enfoca el esfuerzo en tus pruebas más flojas.`, color: '#22c55e' };
    if (improving && diff > 0)
      return { text: `Tendencia positiva sostenida. +${diff.toFixed(1)} pts en la última sesión. Sigue con este ritmo.`, color: '#22c55e' };
    if (declining && diff < 0)
      return { text: `Bajada en las últimas sesiones (${diff.toFixed(1)} pts). Revisa la carga de entrenamiento o el descanso.`, color: '#ef4444' };
    if (diff === 0)
      return { text: `Estancamiento. Para romperlo, aumenta la intensidad o varía el estímulo de entrenamiento.`, color: '#f59e0b' };
    if (diff > 0)
      return { text: `Mejora de +${diff.toFixed(1)} pts respecto a la sesión anterior. Buen trabajo.`, color: '#f97316' };
    return { text: `Ligera bajada de ${Math.abs(diff).toFixed(1)} pts. Puede ser fatiga puntual, observa la tendencia.`, color: '#f59e0b' };
  }, [testHistoryData]);

  // ── Récords personales ───────────────────────────────────────────────────
  const recordsData = useMemo(() => {
    return tests.map(test => {
      const best = profile.bestMarks?.[test.name];
      const current = currentStats.find(s => s.name === test.name);

      // Historial de esa prueba ordenado cronológicamente
      const testHistory = [...history]
        .filter(h => h.type === 'mark' && h.scores.some(s => s.name === test.name && s.value))
        .sort((a, b) => a.timestamp - b.timestamp);

      // Penúltima marca para comparar mejora
      const prevEntry = testHistory.length >= 2 ? testHistory[testHistory.length - 2] : null;
      const prevScore = prevEntry?.scores.find(s => s.name === test.name);

      return {
        name: test.name,
        best,
        currentScore: current,
        prevValue: prevScore?.value ?? null,
        prevScore: prevScore?.score ?? null,
        sessionCount: testHistory.length,
      };
    });
  }, [tests, profile.bestMarks, currentStats, history]);

  // ── Stats resumen General ─────────────────────────────────────────────────
  const totalScore  = currentStats.reduce((acc, s) => acc + s.score, 0);
  const avgScore    = currentStats.filter(s => s.value).length > 0
    ? totalScore / currentStats.filter(s => s.value).length : 0;
  const isApto      = currentStats.filter(s => s.value).length === tests.length &&
    currentStats.every(s => s.score >= 5);
  const bestTest    = [...currentStats].filter(s => s.value).sort((a, b) => b.score - a.score)[0];
  const worstTest   = [...currentStats].filter(s => s.value).sort((a, b) => a.score - b.score)[0];
  const workoutCount = history.filter(h => h.type === 'workout').length;

  const priorityMsg = useMemo(() => {
    if (!worstTest) return null;
    if (worstTest.score === 0)
      return { text: `${worstTest.name} está por debajo del mínimo. Sin el 5.0 aquí la oposición termina.`, color: '#ef4444', level: 'critical' };
    if (worstTest.score < 7)
      return { text: `Tu prueba más floja es ${worstTest.name} (${worstTest.score} pts). Mejorarla un punto sube tu media directamente.`, color: '#f97316', level: 'warning' };
    return { text: 'Todas las pruebas en nivel competitivo. Sigue puliendo para asegurar la plaza.', color: '#22c55e', level: 'ok' };
  }, [worstTest]);

  // ── Estado vacío ──────────────────────────────────────────────────────────
  if (history.length === 0) {
    return (
      <div className="page-content">
        <main className="main" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '80vh', textAlign: 'center' }}>
          <span style={{ fontSize: '64px', marginBottom: '20px' }}>📈</span>
          <h2 style={{ color: 'white' }}>Sin historial</h2>
          <p style={{ color: 'var(--text-muted)', padding: '0 40px' }}>
            Registra marcas en la calculadora para ver tu evolución aquí.
          </p>
        </main>
      </div>
    );
  }

  // ── Tooltip gráfico detalle ───────────────────────────────────────────────
  const ChartTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    const d = payload[0].payload;
    return (
      <div style={{ background: '#1a2234', padding: '10px 14px', border: '1px solid var(--primary)', borderRadius: '12px' }}>
        <p style={{ margin: 0, fontSize: '10px', color: 'var(--text-muted)', fontWeight: '700' }}>{d.dateLabel}</p>
        <p style={{ margin: '4px 0', fontSize: '18px', fontWeight: '900', color: 'white' }}>{d.value}</p>
        <p style={{ margin: 0, fontSize: '12px', color: 'var(--primary)', fontWeight: '900' }}>{d.points} pts</p>
      </div>
    );
  };

  return (
    <div className="page-content">
      <main className="main" style={{ paddingTop: 'calc(16px + env(safe-area-inset-top))', paddingBottom: '120px' }}>

        {/* ── TABS ── */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '6px', marginBottom: '24px', flexWrap: 'wrap' }}>
          {([
            { id: 'general',      label: 'General' },
            { id: 'detailed',     label: 'Detalle' },
            { id: 'records',      label: 'Récords' },
            { id: 'achievements', label: `Logros ${unlockedCount > 0 ? `· ${unlockedCount}/${achievements.length}` : ''}` },
          ] as { id: Tab; label: string }[]).map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: '8px 16px',
                borderRadius: '99px',
                fontSize: '13px',
                fontWeight: '800',
                border: activeTab === tab.id ? 'none' : '1px solid rgba(255,255,255,0.1)',
                background: activeTab === tab.id ? 'var(--primary)' : 'rgba(255,255,255,0.04)',
                color: activeTab === tab.id ? 'black' : 'var(--text-muted)',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* ════════════════════════════════════════════════════
            TAB: GENERAL
        ════════════════════════════════════════════════════ */}
        {activeTab === 'general' && (
          <div>
            {/* Radar chart */}
            <div style={{ position: 'relative', width: '100%', height: '280px', marginBottom: '8px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="75%">
                  <PolarGrid stroke="rgba(255,255,255,0.08)" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: 'var(--text-muted)', fontSize: 11, fontWeight: '700' }} />
                  <PolarRadiusAxis domain={[0, 10]} tick={false} axisLine={false} />
                  <Radar
                    dataKey="A"
                    stroke="var(--primary)"
                    fill="var(--primary)"
                    fillOpacity={0.4}
                    strokeWidth={2.5}
                    isAnimationActive={false}
                    dot={(props: any) => {
                      const { cx, cy, payload } = props;
                      const isActive = activeRadarData?.subject === payload.subject;
                      return (
                        <g key={`dot-${payload.subject}`}
                          onClick={e => { e.stopPropagation(); setActiveRadarData(isActive ? null : payload); }}
                          style={{ cursor: 'pointer' }}
                        >
                          <circle cx={cx} cy={cy} r={22} fill="transparent" />
                          <circle cx={cx} cy={cy} r={isActive ? 7 : 4}
                            fill={isActive ? 'white' : 'var(--primary)'}
                            stroke={isActive ? 'var(--primary)' : 'none'}
                            strokeWidth={2}
                          />
                        </g>
                      );
                    }}
                    activeDot={false}
                  />
                </RadarChart>
              </ResponsiveContainer>

              {/* Tooltip radar al centro */}
              {activeRadarData && (
                <div
                  onClick={() => setActiveRadarData(null)}
                  style={{
                    position: 'absolute', top: '50%', left: '50%',
                    transform: 'translate(-50%, -50%)',
                    background: '#111827', padding: '18px 24px',
                    border: '2px solid var(--primary)', borderRadius: '20px',
                    textAlign: 'center', minWidth: '160px', zIndex: 100,
                  }}
                >
                  <p style={{ margin: 0, fontSize: '10px', fontWeight: '900', color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '1px' }}>
                    {testEmoji[activeRadarData.fullSubject]} {activeRadarData.fullSubject === 'Natacion' ? 'Natación' : activeRadarData.fullSubject}
                  </p>
                  <p style={{ margin: '8px 0 4px', fontSize: '40px', fontWeight: '900', color: 'white', lineHeight: 1 }}>
                    {activeRadarData.A.toFixed(1)}
                  </p>
                  <p style={{ margin: 0, fontSize: '13px', color: 'rgba(255,255,255,0.6)' }}>
                    {activeRadarData.value !== '---' ? activeRadarData.value : 'Sin marca'}
                  </p>
                  <p style={{ margin: '10px 0 0', fontSize: '9px', color: 'var(--text-muted)' }}>Toca para cerrar</p>
                </div>
              )}
            </div>

            {/* Métricas resumen */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', padding: '0 0 16px' }}>
              {[
                { label: 'Total', value: totalScore.toFixed(1), sub: '/ 60 pts', color: 'white' },
                { label: 'Media', value: avgScore.toFixed(1), sub: 'por prueba', color: getScoreColor(avgScore) },
                { label: 'Estado', value: isApto ? 'APTO' : 'No apto', sub: '', color: isApto ? '#22c55e' : '#ef4444' },
                { label: 'Mejor prueba', value: bestTest ? `${testEmoji[bestTest.name] ?? ''} ${bestTest.score}` : '–', sub: bestTest?.name ?? '', color: '#22c55e' },
                { label: 'A mejorar', value: worstTest ? `${testEmoji[worstTest.name] ?? ''} ${worstTest.score}` : '–', sub: worstTest?.name ?? '', color: getScoreColor(worstTest?.score ?? 0) },
                { label: 'Sesiones', value: String(workoutCount), sub: 'entren.', color: 'var(--primary)' },
              ].map((m, i) => (
                <div key={i} style={{
                  background: 'var(--card-bg)',
                  border: '1px solid rgba(255,255,255,0.05)',
                  borderRadius: '14px',
                  padding: '12px 10px',
                  textAlign: 'center',
                }}>
                  <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: '800' }}>{m.label}</p>
                  <p style={{ margin: '4px 0 0', fontSize: '18px', fontWeight: '900', color: m.color, lineHeight: 1 }}>{m.value}</p>
                  {m.sub && <p style={{ margin: '2px 0 0', fontSize: '9px', color: 'var(--text-muted)' }}>{m.sub}</p>}
                </div>
              ))}
            </div>

            {/* Banner de prioridad */}
            {priorityMsg && (
              <div style={{
                padding: '16px 20px',
                borderRadius: '16px',
                background: priorityMsg.level === 'critical' ? 'rgba(239,68,68,0.08)' :
                            priorityMsg.level === 'warning'  ? 'rgba(249,115,22,0.08)' : 'rgba(34,197,94,0.08)',
                borderLeft: `4px solid ${priorityMsg.color}`,
                border: `1px solid ${priorityMsg.color}30`,
              }}>
                <p style={{ margin: 0, fontSize: '9px', fontWeight: '900', color: priorityMsg.color, textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '6px' }}>
                  {priorityMsg.level === 'critical' ? '🚨 Bloque crítico' : priorityMsg.level === 'warning' ? '⚠️ Zona de mejora' : '✓ Nivel competitivo'}
                </p>
                <p style={{ margin: 0, fontSize: '14px', color: 'white', lineHeight: 1.5 }}>{priorityMsg.text}</p>
              </div>
            )}
          </div>
        )}

        {/* ════════════════════════════════════════════════════
            TAB: DETALLE
        ════════════════════════════════════════════════════ */}
        {activeTab === 'detailed' && (
          <div>
            {/* Selector rango de tiempo */}
            <div className="range-selector" style={{ marginBottom: '4px' }}>
              {(['30d', '3m', '1y', 'all'] as TimeRange[]).map(r => (
                <button key={r} onClick={() => setTimeRange(r)} className={timeRange === r ? 'active' : ''}>
                  {r === 'all' ? 'Todo' : r.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Selector de prueba */}
            <div className="test-selector-scroll" style={{ marginBottom: '16px' }}>
              {tests.map(t => (
                <button key={t.name} onClick={() => setSelectedTest(t.name)} className={selectedTest === t.name ? 'active' : ''}>
                  {testEmoji[t.name]} {t.name === 'Natacion' ? 'Natación' : t.name}
                </button>
              ))}
            </div>

            {/* Gráfico */}
            <section className="card" style={{ padding: '18px 16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <div>
                  <p style={{ margin: 0, fontSize: '10px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '1px' }}>
                    Evolución
                  </p>
                  <p style={{ margin: '2px 0 0', fontSize: '16px', fontWeight: '900', color: 'white' }}>
                    {testEmoji[selectedTest]} {selectedTest === 'Natacion' ? 'Natación' : selectedTest}
                  </p>
                </div>
                <div style={{ padding: '5px 12px', background: 'rgba(255,255,255,0.05)', borderRadius: '99px', fontSize: '11px', color: 'var(--text-muted)', fontWeight: '800' }}>
                  {testHistoryData.length} registros
                </div>
              </div>

              {testHistoryData.length >= 2 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={testHistoryData} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="dateLabel" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 9 }} />
                    <YAxis
                      domain={['auto', 'auto']}
                      reversed={testCriteria?.betterIs === 'lower'}
                      tickFormatter={formatYAxis}
                      axisLine={false} tickLine={false}
                      tick={{ fill: '#64748b', fontSize: 9 }}
                    />
                    <Tooltip content={<ChartTooltip />} />
                    <Line
                      type="monotone"
                      dataKey="numericValue"
                      stroke="var(--primary)"
                      strokeWidth={3}
                      dot={{ fill: 'var(--primary)', r: 5, strokeWidth: 0 }}
                      activeDot={{ r: 8, stroke: 'white', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div style={{ height: '120px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <p style={{ fontSize: '13px', color: 'var(--text-muted)', textAlign: 'center' }}>
                    Necesitas al menos 2 registros de {selectedTest === 'Natacion' ? 'Natación' : selectedTest} para ver la gráfica.
                  </p>
                </div>
              )}

              {/* Insight */}
              <div style={{
                marginTop: '16px', padding: '12px 16px',
                borderRadius: '12px', background: 'rgba(255,255,255,0.03)',
                borderLeft: `4px solid ${insight.color}`,
              }}>
                <p style={{ margin: 0, fontSize: '13px', color: 'white', lineHeight: 1.5 }}>{insight.text}</p>
              </div>
            </section>

            {/* Mini stats de la prueba seleccionada */}
            {(() => {
              const stat = currentStats.find(s => s.name === selectedTest);
              const best = profile.bestMarks?.[selectedTest];
              const scores = testHistoryData.map(d => d.points as number).filter(Boolean);
              const maxSeen = scores.length ? Math.max(...scores) : 0;
              const minSeen = scores.length ? Math.min(...scores) : 0;
              if (!stat?.value) return null;
              return (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginTop: '12px' }}>
                  {[
                    { label: 'Marca actual', value: stat.value, color: getScoreColor(stat.score) },
                    { label: 'Mejor marca', value: best?.value ?? '–', color: '#facc15' },
                    { label: 'Mejor puntuación', value: `${maxSeen} pts`, color: '#22c55e' },
                    { label: 'Peor puntuación', value: `${minSeen} pts`, color: '#ef4444' },
                  ].map((m, i) => (
                    <div key={i} style={{
                      background: 'var(--card-bg)',
                      border: '1px solid rgba(255,255,255,0.05)',
                      borderRadius: '14px',
                      padding: '12px 14px',
                    }}>
                      <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', fontWeight: '800', textTransform: 'uppercase' }}>{m.label}</p>
                      <p style={{ margin: '4px 0 0', fontSize: '18px', fontWeight: '900', color: m.color }}>{m.value}</p>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        )}

        {/* ════════════════════════════════════════════════════
            TAB: RÉCORDS
        ════════════════════════════════════════════════════ */}
        {activeTab === 'records' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <p style={{ margin: '0 0 4px', fontSize: '12px', color: 'var(--text-muted)' }}>
              Tus mejores marcas históricas en cada prueba.
            </p>
            {recordsData.map(rec => {
              const hasRecord = !!rec.best?.value;
              const scoreColor = rec.currentScore?.score ? getScoreColor(rec.currentScore.score) : 'rgba(255,255,255,0.2)';
              const scoreDiff = rec.currentScore && rec.prevScore !== null
                ? rec.currentScore.score - rec.prevScore : null;

              return (
                <div key={rec.name} style={{
                  background: 'var(--card-bg)',
                  border: `1px solid ${hasRecord ? scoreColor + '30' : 'rgba(255,255,255,0.05)'}`,
                  borderRadius: '18px',
                  padding: '16px 18px',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{ fontSize: '24px' }}>{testEmoji[rec.name] ?? '🏅'}</span>
                      <div>
                        <p style={{ margin: 0, fontSize: '13px', fontWeight: '900', color: 'white' }}>
                          {rec.name === 'Natacion' ? 'Natación' : rec.name}
                        </p>
                        <p style={{ margin: '2px 0 0', fontSize: '10px', color: 'var(--text-muted)' }}>
                          {rec.sessionCount} {rec.sessionCount === 1 ? 'registro' : 'registros'}
                        </p>
                      </div>
                    </div>

                    {/* Puntuación actual */}
                    <div style={{ textAlign: 'right' }}>
                      <p style={{ margin: 0, fontSize: '28px', fontWeight: '900', color: scoreColor, lineHeight: 1 }}>
                        {rec.currentScore?.score ?? '–'}
                      </p>
                      <p style={{ margin: '2px 0 0', fontSize: '9px', color: 'var(--text-muted)' }}>pts actuales</p>
                    </div>
                  </div>

                  {hasRecord ? (
                    <div style={{ marginTop: '14px', display: 'flex', gap: '10px' }}>
                      {/* Récord personal */}
                      <div style={{
                        flex: 1, padding: '10px 12px',
                        background: 'rgba(250,204,21,0.08)',
                        border: '1px solid rgba(250,204,21,0.2)',
                        borderRadius: '12px',
                      }}>
                        <p style={{ margin: 0, fontSize: '9px', color: '#facc15', fontWeight: '900', textTransform: 'uppercase' }}>🏆 Récord</p>
                        <p style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: '900', color: 'white' }}>{rec.best!.value}</p>
                        <p style={{ margin: '2px 0 0', fontSize: '10px', color: 'var(--text-muted)' }}>
                          {new Date(rec.best!.timestamp).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: '2-digit' })}
                        </p>
                      </div>

                      {/* Comparativa anterior */}
                      {rec.prevValue && (
                        <div style={{
                          flex: 1, padding: '10px 12px',
                          background: 'rgba(255,255,255,0.03)',
                          border: '1px solid rgba(255,255,255,0.06)',
                          borderRadius: '12px',
                        }}>
                          <p style={{ margin: 0, fontSize: '9px', color: 'var(--text-muted)', fontWeight: '900', textTransform: 'uppercase' }}>Anterior</p>
                          <p style={{ margin: '4px 0 0', fontSize: '20px', fontWeight: '900', color: 'rgba(255,255,255,0.5)' }}>{rec.prevValue}</p>
                          {scoreDiff !== null && scoreDiff !== 0 && (
                            <p style={{ margin: '2px 0 0', fontSize: '11px', fontWeight: '900', color: scoreDiff > 0 ? '#22c55e' : '#ef4444' }}>
                              {scoreDiff > 0 ? `+${scoreDiff.toFixed(1)}` : scoreDiff.toFixed(1)} pts
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{ marginTop: '12px', padding: '10px', background: 'rgba(255,255,255,0.02)', borderRadius: '10px', textAlign: 'center' }}>
                      <p style={{ margin: 0, fontSize: '12px', color: 'rgba(255,255,255,0.2)', fontStyle: 'italic' }}>Sin marca registrada</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ════════════════════════════════════════════════════
            TAB: LOGROS
        ════════════════════════════════════════════════════ */}
        {activeTab === 'achievements' && (
          <div>
            {/* Progreso global de logros */}
            <div style={{ marginBottom: '20px', padding: '16px 18px', background: 'var(--card-bg)', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <p style={{ margin: 0, fontSize: '13px', fontWeight: '800', color: 'white' }}>
                  {unlockedCount} de {achievements.length} logros desbloqueados
                </p>
                <p style={{ margin: 0, fontSize: '12px', color: 'var(--primary)', fontWeight: '900' }}>
                  {Math.round((unlockedCount / achievements.length) * 100)}%
                </p>
              </div>
              <div style={{ height: '6px', borderRadius: '99px', background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                <div style={{
                  height: '100%', borderRadius: '99px',
                  width: `${(unlockedCount / achievements.length) * 100}%`,
                  background: 'var(--primary)',
                  transition: 'width 0.5s ease',
                }} />
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {achievements.map(a => {
                const isUnlocked = profile.achievements?.includes(a.id);
                return (
                  <div key={a.id} style={{
                    display: 'flex', alignItems: 'center', gap: '14px',
                    background: isUnlocked ? 'rgba(249,115,22,0.07)' : 'var(--card-bg)',
                    padding: '14px 16px',
                    borderRadius: '16px',
                    border: `1px solid ${isUnlocked ? 'rgba(249,115,22,0.25)' : 'rgba(255,255,255,0.04)'}`,
                    opacity: isUnlocked ? 1 : 0.5,
                  }}>
                    <div style={{
                      fontSize: '26px', width: '48px', height: '48px',
                      background: isUnlocked ? 'rgba(249,115,22,0.12)' : 'rgba(255,255,255,0.04)',
                      borderRadius: '12px',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0,
                    }}>
                      {isUnlocked ? a.icon : '🔒'}
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ margin: 0, fontSize: '14px', fontWeight: '800', color: isUnlocked ? 'white' : 'var(--text-muted)' }}>
                        {a.title}
                      </p>
                      <p style={{ margin: '3px 0 0', fontSize: '12px', color: 'var(--text-muted)' }}>
                        {a.description}
                      </p>
                    </div>
                    {isUnlocked && (
                      <span style={{ fontSize: '18px', color: 'var(--primary)', flexShrink: 0 }}>✓</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </main>
    </div>
  );
};

export default Progress;
