import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { HashRouter as Router, Routes, Route, NavLink, useLocation } from 'react-router-dom';
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';
import { Preferences } from '@capacitor/preferences';
import './App.css';
import { calculateScore, tests, oppositions, allScoringCriteria, parseValue } from './scoring';
import type { TestScore, UserProfile, SessionRecord } from './types';
import { migrateProfile } from './utils/migrations';
import { STORAGE_KEYS } from './constants';

import Home from './pages/Home';
import CalculatorPage from './pages/Calculator';
import Progress from './pages/Progress';
import Training from './pages/Training';
import Advice from './pages/Advice';
import Diagnostic from './pages/Diagnostic';

import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { achievements } from './data/achievements';

const NAV_ITEMS = [
  { to: '/',           emoji: '🏠', label: 'Inicio'     },
  { to: '/calculator', emoji: '🧮', label: 'Marcas'     },
  { to: '/progress',   emoji: '📈', label: 'Progreso'   },
  { to: '/training',   emoji: '🏋️', label: 'Entrena'   },
  { to: '/advice',     emoji: '💡', label: 'Recursos'   },
];

const PageTransition: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.2, ease: 'easeOut' }}
    style={{ height: '100%', width: '100%' }}
  >
    {children}
  </motion.div>
);

const AppContent: React.FC<{
  profile: UserProfile;
  big6Stats: TestScore[];
  history: SessionRecord[];
  onUpdateProfile: (u: Partial<UserProfile>) => void;
  onSaveSession: (type: 'mark' | 'workout', timestamp?: number, specificScores?: TestScore[], title?: string, rpe?: number, notes?: string, exercises?: any[]) => Promise<string>;
  onUpdateStreak: (p: UserProfile) => void;
  onResetData: () => void;
}> = ({ profile, big6Stats, history, onUpdateProfile, onSaveSession, onUpdateStreak, onResetData }) => {
  const location = useLocation();
  const [showDiagnostic, setShowDiagnostic] = useState(false);
  const [notification, setNotification] = useState<{ msg: string; type: 'success' | 'info' | 'error' } | null>(null);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const activeOpposition = useMemo(
    () => oppositions.find(o => o.id === profile.activeOppositionId) || oppositions[0],
    [profile.activeOppositionId]
  );

  if (showDiagnostic) {
    return (
      <Diagnostic
        profile={profile}
        onUpdateProfile={onUpdateProfile}
        onComplete={() => setShowDiagnostic(false)}
        currentStats={big6Stats}
        history={history}
      />
    );
  }

  return (
    <div className="app">
      <div className="page-container">
        <AnimatePresence>
          {notification && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 10 }}
              exit={{ opacity: 0, y: -20 }}
              style={{
                position: 'fixed',
                top: 'env(safe-area-inset-top, 20px)',
                left: '20px', right: '20px',
                zIndex: 100000,
                background: notification.type === 'error' ? 'var(--error)' : 'var(--primary)',
                color: 'black',
                padding: '12px 20px',
                borderRadius: '12px',
                fontWeight: '900',
                fontSize: '13px',
                textAlign: 'center',
                boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
                textTransform: 'uppercase',
              }}
            >
              {notification.msg}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={
              <PageTransition>
                <Home
                  stats={big6Stats}
                  profile={profile}
                  opposition={activeOpposition}
                  wod=""
                  onUpdateProfile={onUpdateProfile}
                  onResetData={onResetData}
                  history={history}
                />
              </PageTransition>
            } />
            <Route path="/calculator" element={
              <PageTransition>
                <CalculatorPage
                  profile={profile}
                  history={history}
                  onSaveSession={async (ts, scores) => {
                    const action = await onSaveSession('mark', ts, scores);
                    if (action === 'created') setNotification({ msg: 'Nueva marca registrada', type: 'success' });
                    if (action === 'updated') setNotification({ msg: 'Marca actualizada correctamente', type: 'success' });
                    if (action === 'deleted') setNotification({ msg: 'Marca eliminada', type: 'info' });
                  }}
                />
              </PageTransition>
            } />
            <Route path="/progress" element={
              <PageTransition>
                <Progress
                  history={history}
                  profile={profile}
                  currentStats={big6Stats}
                  onDeleteRecord={(recordId, testName) => {
                    const record = history.find(h => h.id === recordId);
                    if (record && window.confirm(`¿Eliminar marca de ${testName}?`)) {
                      onSaveSession('mark', record.timestamp, [{ name: testName, value: '', score: 0 }]);
                    }
                  }}
                  onUpdateRecord={(id, testName, newValue) => {
                    const record = history.find(h => h.id === id);
                    if (record) {
                      const scoreObj = calculateScore(testName, newValue, profile.gender, profile.activeOppositionId);
                      onSaveSession('mark', record.timestamp, [scoreObj]);
                    }
                  }}
                />
              </PageTransition>
            } />
            <Route path="/training" element={
              <PageTransition>
                <Training
                  history={history}
                  profile={profile}
                  onSaveWorkout={(title, rpe, notes, exercises) => {
                    onSaveSession('workout', Date.now(), [], title, rpe, notes, exercises);
                    onUpdateStreak(profile);
                  }}
                  onStartDiagnostic={() => setShowDiagnostic(true)}
                />
              </PageTransition>
            } />
            <Route path="/advice" element={
              <PageTransition>
                <Advice currentStats={big6Stats} profile={profile} />
              </PageTransition>
            } />
          </Routes>
        </AnimatePresence>
      </div>

      {/* Bottom nav con etiquetas de texto */}
      <nav className="bottom-nav">
        {NAV_ITEMS.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}
            aria-label={item.label}
            style={{ flexDirection: 'column', gap: '2px', height: 'auto', padding: '8px 0' }}
          >
            <span className="nav-icon" style={{ fontSize: '22px', lineHeight: 1 }}>{item.emoji}</span>
            <span style={{ fontSize: '9px', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.3px' }}>
              {item.label}
            </span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

// ── App root ──────────────────────────────────────────────────────────────────
const App: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile>({
    name: 'Aspirante',
    gender: 'male',
    activeOppositionId: 'consorcio_vlc',
    bestMarks: {},
    targets: {},
    streak: 0,
    achievements: [],
    avatarId: '1',
  });
  const [history, setHistory] = useState<SessionRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const handleUpdateProfile = useCallback(async (updates: Partial<UserProfile>) => {
    setProfile(prev => {
      const updated = { ...prev, ...updates };
      try {
        JSON.stringify(updated);
        Preferences.set({
          key: STORAGE_KEYS.PROFILE,
          value: JSON.stringify(updated),
        }).catch(err => console.error('Error saving profile:', err));
      } catch (err) {
        console.error('Error serializing profile:', err);
      }
      return updated;
    });
  }, []);

  const updateStreak = useCallback((currentProfile: UserProfile) => {
    const today = new Date().toISOString().split('T')[0];
    const lastDate = currentProfile.lastWorkoutDate;
    if (lastDate === today) return;

    let newStreak = currentProfile.streak || 0;
    if (lastDate) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      newStreak = lastDate === yesterday.toISOString().split('T')[0] ? newStreak + 1 : 1;
    } else {
      newStreak = 1;
    }

    handleUpdateProfile({ streak: newStreak, lastWorkoutDate: today });

    if (newStreak > 0 && newStreak % 5 === 0) {
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 }, colors: ['#f97316', '#ffffff'] });
    }
  }, [handleUpdateProfile]);

  const big6Stats = useMemo(() => {
    const latest: Record<string, string> = {};
    const sorted = [...history].sort((a, b) => b.timestamp - a.timestamp);
    tests.forEach(test => {
      const rec = sorted.find(s => s.type === 'mark' && s.scores.some(ts => ts.name === test.name && ts.value?.trim()));
      if (rec) {
        const sc = rec.scores.find(ts => ts.name === test.name);
        if (sc) latest[test.name] = sc.value;
      }
    });
    return tests.map(test => calculateScore(test.name, latest[test.name] || '', profile.gender, profile.activeOppositionId));
  }, [history, profile.gender, profile.activeOppositionId]);

  const checkAchievements = useCallback((currentStats: TestScore[], currentHistory: SessionRecord[], currentProfile: UserProfile) => {
    const unlockedIds = currentProfile.achievements || [];
    const newUnlocks = achievements.filter(a => !unlockedIds.includes(a.id) && a.condition(currentStats, currentHistory, currentProfile));
    if (newUnlocks.length > 0) {
      handleUpdateProfile({ achievements: [...unlockedIds, ...newUnlocks.map(a => a.id)] });
      newUnlocks.forEach((_, i) => setTimeout(() => {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 }, colors: ['#FFD700', '#FFA500'] });
      }, i * 1000));
    }
  }, [handleUpdateProfile]);

  useEffect(() => {
    if (!isLoading) checkAchievements(big6Stats, history, profile);
  }, [big6Stats, history, profile.streak, isLoading]);

  const bestMarks = useMemo(() => {
    const bests: Record<string, { value: string; timestamp: number }> = {};
    const sorted = [...history].sort((a, b) => a.timestamp - b.timestamp);
    const opp = oppositions.find(o => o.id === profile.activeOppositionId) || oppositions[0];

    tests.forEach(test => {
      const criteria = allScoringCriteria[opp.scoringTable][test.name];
      if (!criteria) return;
      let bestVal: number | null = null;
      let bestStr = '';
      let bestTime = 0;

      sorted.forEach(rec => {
        const sc = rec.scores.find(ts => ts.name === test.name);
        if (!sc?.value) return;
        const val = parseValue(sc.value, criteria.unit);
        if (isNaN(val)) return;
        if (bestVal === null || (criteria.betterIs === 'lower' ? val < bestVal : val > bestVal)) {
          bestVal = val; bestStr = sc.value; bestTime = rec.timestamp;
        }
      });

      if (bestStr) bests[test.name] = { value: bestStr, timestamp: bestTime };
    });
    return bests;
  }, [history, profile.activeOppositionId]);

  // PB confetti
  const prevBestMarks = React.useRef<Record<string, string>>({});
  useEffect(() => {
    if (isLoading) return;
    let brokePB = false;
    Object.keys(bestMarks).forEach(key => {
      const cur = bestMarks[key].value;
      const prev = prevBestMarks.current[key];
      if (cur && prev && cur !== prev) {
        const criteria = allScoringCriteria[profile.activeOppositionId]?.[key];
        if (criteria) {
          const isBetter = criteria.betterIs === 'lower'
            ? parseValue(cur, criteria.unit) < parseValue(prev, criteria.unit)
            : parseValue(cur, criteria.unit) > parseValue(prev, criteria.unit);
          if (isBetter) brokePB = true;
        }
      }
      prevBestMarks.current[key] = cur;
    });
    if (brokePB) {
      confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 }, colors: ['#f97316', '#ffffff', '#fb923c'] });
      Haptics.impact({ style: ImpactStyle.Heavy });
    }
  }, [bestMarks, isLoading, profile.activeOppositionId]);

  // Load data
  useEffect(() => {
    const loadData = async () => {
      try {
        const { value: savedProfile } = await Preferences.get({ key: STORAGE_KEYS.PROFILE });
        const { value: savedHistory } = await Preferences.get({ key: STORAGE_KEYS.HISTORY });
        const { value: savedInputs }  = await Preferences.get({ key: 'bomberapp_inputs' });

        let loadedHistory: SessionRecord[] = [];
        if (savedHistory) {
          try {
            const parsed = JSON.parse(savedHistory);
            if (Array.isArray(parsed)) loadedHistory = parsed;
          } catch (e) { console.error('Error parsing history', e); }
        }

        if (loadedHistory.length === 0 && savedInputs) {
          try {
            const inputsObj = JSON.parse(savedInputs);
            const initialScores = tests.map(t => calculateScore(t.name, inputsObj[t.name] || '', 'male', 'consorcio_vlc')).filter(s => s.value);
            if (initialScores.length > 0) {
              loadedHistory = [{
                id: 'migration_' + Date.now(),
                timestamp: Date.now() - 1000,
                type: 'mark',
                totalScore: initialScores.reduce((acc, s) => acc + s.score, 0),
                scores: initialScores,
                gender: 'male',
              }];
            }
          } catch (e) { console.error('Error in inputs migration', e); }
        }
        setHistory(loadedHistory);

        if (savedProfile) {
          try {
            const { profile: migrated } = migrateProfile(savedProfile);
            setProfile(prev => ({ ...prev, ...migrated }));
          } catch (e) { console.error('Error migrating profile', e); }
        }
      } catch (err) {
        console.error('Critical error loading data', err);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const recalculateTotalScores = (h: SessionRecord[]): SessionRecord[] => {
    const latestKnown: Record<string, number> = {};
    return [...h]
      .sort((a, b) => a.timestamp - b.timestamp)
      .map(rec => {
        if (rec.type === 'mark') rec.scores.forEach(s => { latestKnown[s.name] = s.score; });
        return { ...rec, totalScore: tests.reduce((sum, t) => sum + (latestKnown[t.name] || 0), 0) };
      })
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, 500);
  };

  const saveMark = useCallback(async (timestamp: number, specificScores: TestScore[]): Promise<'created' | 'updated' | 'deleted' | 'none'> => {
    const testName = specificScores[0]?.name ?? null;
    let actionResult: 'created' | 'updated' | 'deleted' | 'none' = 'none';

    setHistory(prev => {
      const updated = [...prev];
      const dateStr = new Date(timestamp).toDateString();
      const idx = updated.findIndex(h => h.type === 'mark' && new Date(h.timestamp).toDateString() === dateStr);
      const active = specificScores.filter(s => s.value?.trim());

      if (active.length > 0) {
        if (idx > -1) {
          const rec = { ...updated[idx], scores: [...updated[idx].scores] };
          active.forEach(aS => {
            const si = rec.scores.findIndex(s => s.name === aS.name);
            if (si > -1) rec.scores[si] = aS; else rec.scores.push(aS);
          });
          updated[idx] = rec;
          actionResult = 'updated';
        } else {
          updated.push({ id: `${timestamp}${testName ? `_${testName}` : ''}`, timestamp, type: 'mark', totalScore: 0, scores: active, gender: profile.gender });
          actionResult = 'created';
        }
      } else if (idx > -1) {
        const rec = { ...updated[idx] };
        if (testName) {
          rec.scores = rec.scores.filter(s => s.name !== testName);
          if (rec.scores.length === 0) updated.splice(idx, 1); else updated[idx] = rec;
        } else {
          updated.splice(idx, 1);
        }
        actionResult = 'deleted';
      }

      if (actionResult !== 'none') Haptics.notification({ type: actionResult === 'deleted' ? NotificationType.Warning : NotificationType.Success });

      const final = recalculateTotalScores(updated);
      Preferences.set({ key: STORAGE_KEYS.HISTORY, value: JSON.stringify(final) }).catch(err => console.error('Error saving history:', err));
      return final;
    });

    return actionResult;
  }, [profile.gender]);

  const saveWorkout = useCallback(async (timestamp: number, title: string, rpe?: number, notes?: string, exercises?: any[]): Promise<'created' | 'updated' | 'deleted' | 'none'> => {
    setHistory(prev => {
      const updated = [...prev, { id: String(timestamp), timestamp, type: 'workout' as const, workoutTitle: title, exercises, totalScore: 0, scores: [], gender: profile.gender, rpe, notes }];
      Haptics.notification({ type: NotificationType.Success });
      const final = recalculateTotalScores(updated);
      Preferences.set({ key: STORAGE_KEYS.HISTORY, value: JSON.stringify(final) }).catch(err => console.error('Error saving history:', err));
      return final;
    });
    return 'created';
  }, [profile.gender]);

  const handleSaveSession = useCallback(async (type: 'mark' | 'workout', timestamp?: number, specificScores?: TestScore[], title?: string, rpe?: number, notes?: string, exercises?: any[]): Promise<'created' | 'updated' | 'deleted' | 'none'> => {
    const t = timestamp || Date.now();
    return type === 'mark' ? saveMark(t, specificScores || []) : saveWorkout(t, title || '', rpe, notes, exercises);
  }, [saveMark, saveWorkout]);

  const handleResetData = useCallback(async () => {
    if (window.confirm('¿Estás seguro de que quieres borrar todos tus datos? Esta acción es irreversible.')) {
      await Preferences.clear();
      window.location.reload();
    }
  }, []);

  if (isLoading) return <div className="loading-screen">Cargando...</div>;

  return (
    <Router>
      <AppContent
        profile={{ ...profile, bestMarks }}
        big6Stats={big6Stats}
        history={history}
        onUpdateProfile={handleUpdateProfile}
        onSaveSession={handleSaveSession}
        onUpdateStreak={updateStreak}
        onResetData={handleResetData}
      />
    </Router>
  );
};

export default App;
