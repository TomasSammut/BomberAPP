import React, { useState, useMemo } from 'react';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { Browser } from '@capacitor/browser';

// ── Tipos ────────────────────────────────────────────────────────────────────
interface AdviceProps {
  currentStats?: { name: string; score: number; value: string }[];
  profile?: { gender: 'male' | 'female'; activeOppositionId: string };
}

// ── Datos ─────────────────────────────────────────────────────────────────────

const DOCS = [
  {
    emoji: '📋',
    title: 'Decreto 163/2019',
    subtitle: 'DOGV · Texto oficial completo',
    tag: 'PDF OFICIAL',
    tagColor: '#38bdf8',
    url: 'https://dogv.gva.es/datos/2019/07/30/pdf/2019_7756.pdf',
  },
  {
    emoji: '🌐',
    title: 'Consorcio Provincial Valencia',
    subtitle: 'Web oficial · Convocatorias y noticias',
    tag: 'WEB OFICIAL',
    tagColor: '#22c55e',
    url: 'https://www.cpbv.es',
  },
  {
    emoji: '🌐',
    title: 'Bomberos Ayuntamiento Valencia',
    subtitle: 'Web oficial · Convocatorias y noticias',
    tag: 'WEB OFICIAL',
    tagColor: '#22c55e',
    url: 'https://www.valencia.es/es/web/bomberos',
  },
  {
    emoji: '📖',
    title: 'Ley 7/2011 SPEIS',
    subtitle: 'Ley de Servicios de Extinción de Incendios CV',
    tag: 'LEGISLACIÓN',
    tagColor: '#f97316',
    url: 'https://dogv.gva.es/datos/2011/04/05/pdf/2011_3638.pdf',
  },
];

interface TestGuide {
  name: string;
  emoji: string;
  intro: string;
  reglamento: string[];
  errores: { titulo: string; desc: string }[];
  consejos: { titulo: string; desc: string }[];
}

const TEST_GUIDES: TestGuide[] = [
  {
    name: 'Cuerda',
    emoji: '🪢',
    intro: 'Prueba de fuerza de tracción pura. Hombres 6m, mujeres 5m desde posición sentado sin ayuda de piernas. Tiempo máximo: 15 segundos.',
    reglamento: [
      'Salida sentado en el suelo, sin contacto de pies con la superficie.',
      'Al menos un brazo agarrado a la cuerda en posición inicial.',
      'Subida solo con brazos en todo el recorrido — ningún apoyo de piernas.',
      'Se permite el roce de la cuerda con cualquier parte del cuerpo.',
      'El tiempo para cuando se toca la marca señalizadora con una mano.',
    ],
    errores: [
      { titulo: 'Pies en la salida', desc: 'Levantarse con ayuda de piernas o pies al inicio es nulidad directa. El juez está mirando los pies.' },
      { titulo: 'Ayuda de piernas en ruta', desc: 'Cualquier flexión de rodillas o enganche de pies durante la subida = No Apto automático.' },
      { titulo: 'No alcanzar la marca', desc: 'Llegar al límite de tiempo sin tocar la señal cuenta como eliminatorio aunque estés a centímetros.' },
    ],
    consejos: [
      { titulo: 'La salida lo es todo', desc: 'El primer movimiento desde el suelo es el más difícil. Practica salidas con el culo pegado al suelo hasta que sea automático.' },
      { titulo: 'Tracciones lastradas', desc: 'Domina series de dominadas con lastre de 10-15kg. Si puedes hacer 5 dominadas con 15kg, la cuerda se vuelve manejable.' },
      { titulo: 'Toalla húmeda', desc: 'Entrena con toallas colgadas del techo para simular el agarre específico de la cuerda lisa.' },
    ],
  },
  {
    name: '3000m',
    emoji: '🏃',
    intro: 'Prueba de resistencia aeróbica en pista de atletismo por calle libre. Sin zapatillas de clavos. Un solo intento. Mínimo: 12:00 hombres / 13:30 mujeres.',
    reglamento: [
      'Prohibido el uso de zapatillas de clavos — usa zapatillas de atletismo o running.',
      'Salida nula si se empieza a correr antes del disparo o pitido.',
      'Cronometraje electrónico con chip. El tiempo para al cruzar la meta.',
      'Máximo 15 aspirantes por tanda en pista.',
      'Descalificación por obstruir, empujar o molestar a otro corredor.',
    ],
    errores: [
      { titulo: 'Salida falsa', desc: 'A diferencia del 60m, aquí NO se permite ninguna salida nula. Una y quedas eliminado.' },
      { titulo: 'Entrar en salida rápido', desc: 'Muchos aspirantes salen a ritmo de 400m y explotan en el km 2. La prueba exige gestión de ritmo, no velocidad punta.' },
      { titulo: 'Zapatillas equivocadas', desc: 'Los clavos están explícitamente prohibidos. Llevarlos el día del examen significa descalificación.' },
    ],
    consejos: [
      { titulo: 'Divide en vueltas', desc: 'Para un 10 necesitas 10:15 (H) = 1:22/vuelta en 400m. Aprende tu ritmo objetivo por vuelta y entrénalo con splits.' },
      { titulo: 'Rodajes en zona 2', desc: 'Base aeróbica sólida: 3 rodajes suaves de 40-50 min semanales a ritmo conversacional antes de meter series.' },
      { titulo: 'Series de 1000m', desc: 'El entrenamiento más específico: 5x1000m a ritmo de examen con 90s de recuperación. Simula la sensación exacta de la prueba.' },
    ],
  },
  {
    name: '60m',
    emoji: '⚡',
    intro: 'Prueba de velocidad en pista de atletismo por calle asignada. Se permite una salida falsa. Foto-finish. Se permiten zapatillas de clavos.',
    reglamento: [
      'Se permite UNA salida falsa por tanda y aspirante.',
      'Cronometraje por foto-finish — el tiempo para cuando el torso cruza la línea.',
      'Si el viento supera los 2 m/s la prueba no se celebra.',
      'Prohibido invadir la calle de otro aspirante o molestarle.',
      'Tiempos con dos decimales (centésimas de segundo).',
    ],
    errores: [
      { titulo: 'Segunda salida nula', desc: 'La primera salida falsa es gratis. La segunda es descalificación directa. No te arriesgues en la segunda salida.' },
      { titulo: 'Frenar antes de la meta', desc: 'El tiempo para en el torso, no en los pies. Muchos deceleran visualmente antes de cruzar y pierden centésimas.' },
      { titulo: 'Mala posición de salida', desc: 'Una salida en posición alta pierde entre 0.15-0.25 segundos respecto a una posición de taco bien ejecutada.' },
    ],
    consejos: [
      { titulo: 'Usa clavos', desc: 'A diferencia del 3000m, aquí están permitidos. Entre zapatillas de running y clavos puede haber 0.2-0.3 segundos.' },
      { titulo: 'La fase de salida (0-20m)', desc: 'El 80% de tu tiempo final se decide en los primeros 20m. Trabaja la explosividad con arrancadas cortas de 10-20m desde posición baja.' },
      { titulo: 'Reacción al disparo', desc: 'Practica salidas con señal auditiva aleatoria. El tiempo de reacción es entrenable y puede valer 0.05-0.1 segundos.' },
    ],
  },
  {
    name: 'Natacion',
    emoji: '🏊',
    intro: 'Natación de 100m (4 largos en piscina de 25m) con cualquier estilo. Bañador y gorro obligatorios. Gafas y tapones permitidos. Un solo intento.',
    reglamento: [
      'Salida desde la plataforma, borde o interior del vaso (en contacto con la pared).',
      'Prohibido caminar por el fondo o apoyarse en las corcheras para avanzar.',
      'Los virajes deben tener contacto físico con la pared — no está permitido dar zancadas sobre el fondo.',
      'Cada largo cuenta si se toca la pared con cualquier parte del cuerpo.',
      'Descalificación si se cambia de calle o se molesta a otro nadador.',
    ],
    errores: [
      { titulo: 'Salida falsa', desc: 'A diferencia del 60m, aquí no hay margen. Cualquier salida anticipada es descalificación inmediata o al final de la prueba.' },
      { titulo: 'Tocar el fondo', desc: 'Apoyarse en el fondo para recuperarse en la parte poco profunda es No Apto automático. Aunque estés agotado, sigue nadando.' },
      { titulo: 'Viraje sin tocar la pared', desc: 'El toque debe ser claro y con suficiente fuerza para activar el sensor electrónico. Un toque suave puede no registrarse.' },
    ],
    consejos: [
      { titulo: 'El viraje ahorra tiempo', desc: 'Tienes 3 virajes en 100m. Mejorar cada viraje 0.5s = 1.5s totales sin nadar más rápido. Entrena virajes específicamente.' },
      { titulo: 'Técnica sobre volumen', desc: 'Para esta distancia, una brazada eficiente vale más que la fuerza. Trabaja con un monitor de natación al menos las primeras semanas.' },
      { titulo: 'Simula el día del examen', desc: 'Entrena en bañador de competición y gorro. La sensación es diferente a entrenar en bañador de entrenamiento. Acostúmbrate.' },
    ],
  },
  {
    name: 'Press Banca',
    emoji: '🏋️',
    intro: 'Máximo de repeticiones en 60 segundos. Hombres 50kg, mujeres 30kg. Posición decúbito supino. Mínimo 20 repeticiones para ser Apto.',
    reglamento: [
      'Partida con brazos extendidos soportando el peso.',
      'Cada repetición: flexión completa (barra toca el pecho) + extensión total de codos.',
      'Agarre ligeramente superior a la anchura de los hombros.',
      'Las repeticiones no válidas se repite el número — el juez no las cuenta.',
      'Un solo intento. No se permite salida nula.',
    ],
    errores: [
      { titulo: 'Repetición parcial', desc: 'La barra debe tocar el pecho y los codos extenderse completamente. El juez repite el mismo número si la rep es parcial. Con 40 reps que hacer, perder 3-4 es crítico.' },
      { titulo: 'Rebote en el pecho', desc: 'Usar el rebote de la barra en el pecho para facilitar la subida es nulidad. La barra debe tocar con control.' },
      { titulo: 'Levantarse del banco', desc: 'Los glúteos deben estar siempre en contacto con el banco. Arquear la espalda levantando el culo anula la repetición.' },
    ],
    consejos: [
      { titulo: 'Entrena el ritmo', desc: 'Para 40 reps en 60s necesitas una rep cada 1.5s. Usa un metrónomo durante el entrenamiento hasta que el ritmo sea automático.' },
      { titulo: 'Resistencia muscular > fuerza máxima', desc: 'Tu 1RM no importa aquí. Entrena series de 20-25 reps con el peso del examen, con descanso corto (60-90s). Acumula volumen.' },
      { titulo: 'Simula el examen en el entrenamiento', desc: 'Haz el test real con cronómetro al menos 1 vez por semana. El estrés del tiempo cambia completamente la ejecución.' },
    ],
  },
  {
    name: 'Torre',
    emoji: '🏗️',
    intro: 'Prueba específica del servicio. Con lastre de 15kg (mochila o chaleco). Sin distinción hombre/mujer en altura, sí en tiempo máximo. Los baremos los fija cada servicio.',
    reglamento: [
      'Lastre de 15kg obligatorio durante todo el recorrido — perderlo es descalificación inmediata.',
      'Se permite una salida falsa. La segunda es descalificación.',
      'Se permiten impulsos y tracciones de paredes y barandillas (salvo en la salida del Ayuntamiento).',
      'En el Ayuntamiento: la bajada debe pisar TODAS las huellas de los escalones — obligatorio.',
      'Cronometraje electrónico en salida y llegada.',
    ],
    errores: [
      { titulo: 'Perder el lastre', desc: 'Si el chaleco o mochila se suelta o cae parte del peso durante el recorrido, descalificación automática. Ajusta bien el equipo antes de salir.' },
      { titulo: 'Saltarse peldaños en bajada (Ayto.)', desc: 'En el Ayuntamiento es obligatorio pisar todas las huellas en la bajada. Bajar de dos en dos es descalificación, aunque subas más rápido.' },
      { titulo: 'Ritmo de salida equivocado', desc: 'La prueba dura 25-30 segundos. Salir al 100% desde el primer escalón agota las piernas antes de llegar. Practica el ritmo con lastre.' },
    ],
    consejos: [
      { titulo: 'Entrena siempre con lastre', desc: 'Entrenar sin los 15kg da tiempos irreales. La distribución del peso cambia el equilibrio y el esfuerzo de piernas. Usa siempre el chaleco.' },
      { titulo: 'Trabaja las escaleras específicamente', desc: 'Series de escaleras con chaleco lastrado (8-10 plantas, x5-6 series). Más útil que el running plano para esta prueba.' },
      { titulo: 'Diferencia Consorcio vs Ayuntamiento', desc: 'Son pruebas completamente distintas. El Consorcio es sprint recto de 18m. El Ayuntamiento es subir-bajar-subir 113 peldaños. Entrena específicamente para tu convocatoria.' },
    ],
  },
];

// ── Tips dinámicos según perfil ───────────────────────────────────────────────
const getDynamicTips = (
  stats?: { name: string; score: number; value: string }[]
): { emoji: string; titulo: string; texto: string; color: string }[] => {
  const tips: { emoji: string; titulo: string; texto: string; color: string }[] = [];
  if (!stats || stats.filter(s => s.value).length === 0) {
    return [
      { emoji: '🎯', titulo: 'Empieza por el diagnóstico', texto: 'Registra tus primeras marcas en la calculadora para recibir consejos personalizados según tus puntos débiles.', color: '#f97316' },
      { emoji: '📋', titulo: 'Conoce el reglamento', texto: 'Muchos aspirantes se eliminan por errores técnicos evitables. Lee las reglas de cada prueba en la sección de abajo antes de tu primer simulacro.', color: '#38bdf8' },
      { emoji: '🏋️', titulo: 'El lastre cambia todo', texto: 'Cuando empieces a entrenar la torre, hazlo siempre con los 15kg desde el primer día. Sin lastre los tiempos no son representativos.', color: '#22c55e' },
    ];
  }

  const withMarks = stats.filter(s => s.value);
  const sorted = [...withMarks].sort((a, b) => a.score - b.score);
  const worst = sorted[0];
  const best = sorted[sorted.length - 1];
  const noApto = withMarks.filter(s => s.score === 0);

  if (noApto.length > 0) {
    tips.push({
      emoji: '🚨',
      titulo: `${noApto[0].name}: Prueba eliminatoria`,
      texto: `Tu ${noApto[0].name} está por debajo del mínimo. Sin el 5.0 en esta prueba, el resto no importa. Prioriza esta prueba por encima de todo.`,
      color: '#ef4444',
    });
  } else if (worst && worst.score < 7) {
    tips.push({
      emoji: '⚠️',
      titulo: `Mejora prioritaria: ${worst.name}`,
      texto: `Con ${worst.score} pts en ${worst.name} estás dejando puntos sobre la mesa. Cada punto que sumes aquí sube directamente tu media total.`,
      color: '#f59e0b',
    });
  }

  if (best && best.score >= 9) {
    tips.push({
      emoji: '🏆',
      titulo: `${best.name}: Punto fuerte`,
      texto: `Tienes ${best.score} pts en ${best.name}. Mantén el nivel con sesiones de mantenimiento y dedica el esfuerzo extra a tus pruebas más flojas.`,
      color: '#22c55e',
    });
  }

  const avgScore = withMarks.reduce((a, b) => a + b.score, 0) / withMarks.length;
  if (avgScore >= 7 && withMarks.length === 6) {
    tips.push({
      emoji: '📈',
      titulo: 'Nivel competitivo',
      texto: `Media de ${avgScore.toFixed(1)} pts con las 6 pruebas. Estás en zona de plaza. Ahora el objetivo es la consistencia: no bajar ninguna prueba por debajo de 6.`,
      color: '#f97316',
    });
  } else if (withMarks.length < 6) {
    tips.push({
      emoji: '📊',
      titulo: 'Completa tu perfil',
      texto: `Tienes ${withMarks.length} de 6 pruebas registradas. Añade las marcas que faltan para ver tu nota real y recibir consejos más precisos.`,
      color: '#38bdf8',
    });
  }

  return tips.slice(0, 3);
};

// ─────────────────────────────────────────────────────────────────────────────
const Advice: React.FC<AdviceProps> = ({ currentStats }) => {
  const [expandedTest, setExpandedTest] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<'reglamento' | 'errores' | 'consejos'>('consejos');

  const dynamicTips = useMemo(
    () => getDynamicTips(currentStats),
    [currentStats]
  );

  const openUrl = async (url: string) => {
    await Haptics.impact({ style: ImpactStyle.Medium });
    try {
      await Browser.open({ url });
    } catch {
      window.open(url, '_blank');
    }
  };

  const toggleTest = (name: string) => {
    setExpandedTest(prev => prev === name ? null : name);
    setExpandedSection('consejos');
    Haptics.impact({ style: ImpactStyle.Light });
  };

  return (
    <div className="page-content">
      <main className="main" style={{ paddingTop: 'calc(16px + env(safe-area-inset-top))', paddingBottom: '120px' }}>

        {/* TÍTULO */}
        <div style={{ marginBottom: '24px' }}>
          <h1 style={{ margin: 0, fontSize: '22px', fontWeight: '900', color: 'white' }}>Recursos</h1>
          <p style={{ margin: '4px 0 0', fontSize: '13px', color: 'var(--text-muted)' }}>
            Guías técnicas, reglamento oficial y documentos
          </p>
        </div>

        {/* ── SECCIÓN: PARA TI ── */}
        <section style={{ marginBottom: '28px' }}>
          <h2 style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1.5px', marginBottom: '12px' }}>
            Para ti
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {dynamicTips.map((tip, i) => (
              <div key={i} style={{
                display: 'flex', gap: '14px', alignItems: 'flex-start',
                padding: '14px 16px',
                background: 'var(--card-bg)',
                borderRadius: '16px',
                borderLeft: `4px solid ${tip.color}`,
                border: `1px solid ${tip.color}25`,
              }}>
                <span style={{ fontSize: '22px', flexShrink: 0, marginTop: '1px' }}>{tip.emoji}</span>
                <div>
                  <p style={{ margin: 0, fontSize: '13px', fontWeight: '800', color: 'white', marginBottom: '4px' }}>{tip.titulo}</p>
                  <p style={{ margin: 0, fontSize: '12px', color: 'var(--text-muted)', lineHeight: 1.5 }}>{tip.texto}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── SECCIÓN: GUÍAS POR PRUEBA ── */}
        <section style={{ marginBottom: '28px' }}>
          <h2 style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1.5px', marginBottom: '12px' }}>
            Guía técnica por prueba
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {TEST_GUIDES.map(guide => {
              const isOpen = expandedTest === guide.name;
              const myStat = currentStats?.find(s => s.name === guide.name);
              const scoreColor = myStat?.value
                ? myStat.score === 0 ? '#ef4444'
                : myStat.score >= 9 ? '#22c55e'
                : myStat.score >= 7 ? '#f97316' : '#f59e0b'
                : 'rgba(255,255,255,0.2)';

              return (
                <div key={guide.name} style={{
                  background: 'var(--card-bg)',
                  borderRadius: '16px',
                  border: `1px solid ${isOpen ? 'rgba(249,115,22,0.3)' : 'rgba(255,255,255,0.05)'}`,
                  overflow: 'hidden',
                  transition: 'border-color 0.2s',
                }}>
                  {/* Cabecera */}
                  <div
                    onClick={() => toggleTest(guide.name)}
                    style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px 16px', cursor: 'pointer' }}
                  >
                    <span style={{ fontSize: '22px', flexShrink: 0 }}>{guide.emoji}</span>
                    <div style={{ flex: 1 }}>
                      <p style={{ margin: 0, fontSize: '14px', fontWeight: '800', color: 'white' }}>
                        {guide.name === 'Natacion' ? 'Natación' : guide.name}
                      </p>
                      {!isOpen && (
                        <p style={{ margin: '2px 0 0', fontSize: '11px', color: 'var(--text-muted)' }}>
                          {guide.intro.slice(0, 55)}…
                        </p>
                      )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
                      {myStat?.value && (
                        <span style={{ fontSize: '14px', fontWeight: '900', color: scoreColor }}>
                          {myStat.score} pts
                        </span>
                      )}
                      <span style={{ color: 'var(--text-muted)', fontSize: '16px', transition: 'transform 0.2s', transform: isOpen ? 'rotate(90deg)' : 'none' }}>›</span>
                    </div>
                  </div>

                  {/* Contenido expandido */}
                  {isOpen && (
                    <div style={{ padding: '0 16px 18px' }}>
                      <p style={{ margin: '0 0 16px', fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: 1.6 }}>
                        {guide.intro}
                      </p>

                      {/* Sub-tabs */}
                      <div style={{ display: 'flex', gap: '6px', marginBottom: '14px' }}>
                        {([
                          { id: 'consejos',    label: '💡 Consejos' },
                          { id: 'errores',     label: '⚠️ Errores' },
                          { id: 'reglamento',  label: '📋 Reglamento' },
                        ] as const).map(tab => (
                          <button
                            key={tab.id}
                            onClick={() => setExpandedSection(tab.id)}
                            style={{
                              padding: '6px 12px', borderRadius: '99px', fontSize: '11px', fontWeight: '800',
                              border: expandedSection === tab.id ? 'none' : '1px solid rgba(255,255,255,0.1)',
                              background: expandedSection === tab.id ? 'var(--primary)' : 'rgba(255,255,255,0.04)',
                              color: expandedSection === tab.id ? 'black' : 'var(--text-muted)',
                              cursor: 'pointer',
                            }}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>

                      {/* Consejos */}
                      {expandedSection === 'consejos' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {guide.consejos.map((c, i) => (
                            <div key={i} style={{ padding: '12px 14px', background: 'rgba(249,115,22,0.06)', borderRadius: '12px', borderLeft: '3px solid rgba(249,115,22,0.4)' }}>
                              <p style={{ margin: 0, fontSize: '12px', fontWeight: '900', color: 'var(--primary)', marginBottom: '4px' }}>{c.titulo}</p>
                              <p style={{ margin: 0, fontSize: '12px', color: 'rgba(255,255,255,0.7)', lineHeight: 1.5 }}>{c.desc}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Errores */}
                      {expandedSection === 'errores' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {guide.errores.map((e, i) => (
                            <div key={i} style={{ padding: '12px 14px', background: 'rgba(239,68,68,0.06)', borderRadius: '12px', borderLeft: '3px solid rgba(239,68,68,0.4)' }}>
                              <p style={{ margin: 0, fontSize: '12px', fontWeight: '900', color: '#ef4444', marginBottom: '4px' }}>✗ {e.titulo}</p>
                              <p style={{ margin: 0, fontSize: '12px', color: 'rgba(255,255,255,0.7)', lineHeight: 1.5 }}>{e.desc}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Reglamento */}
                      {expandedSection === 'reglamento' && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                          {guide.reglamento.map((r, i) => (
                            <div key={i} style={{ display: 'flex', gap: '10px', alignItems: 'flex-start', padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: '10px' }}>
                              <span style={{ color: 'var(--primary)', fontWeight: '900', fontSize: '12px', flexShrink: 0, marginTop: '1px' }}>{i + 1}.</span>
                              <p style={{ margin: 0, fontSize: '12px', color: 'rgba(255,255,255,0.75)', lineHeight: 1.5 }}>{r}</p>
                            </div>
                          ))}
                          <p style={{ margin: '8px 0 0', fontSize: '10px', color: 'var(--text-muted)', fontStyle: 'italic' }}>
                            Fuente: Decreto 163/2019 del Consell — DOGV 8602
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ── SECCIÓN: DOCUMENTOS OFICIALES ── */}
        <section>
          <h2 style={{ fontSize: '10px', fontWeight: '900', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1.5px', marginBottom: '12px' }}>
            Documentos oficiales
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {DOCS.map((doc, i) => (
              <button
                key={i}
                onClick={() => openUrl(doc.url)}
                style={{
                  display: 'flex', alignItems: 'center', gap: '14px',
                  padding: '14px 16px',
                  background: 'var(--card-bg)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  borderRadius: '16px',
                  textAlign: 'left', width: '100%', cursor: 'pointer',
                }}
              >
                <span style={{ fontSize: '22px', flexShrink: 0 }}>{doc.emoji}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ margin: 0, fontSize: '14px', fontWeight: '800', color: 'white' }}>{doc.title}</p>
                  <p style={{ margin: '2px 0 0', fontSize: '11px', color: 'var(--text-muted)' }}>{doc.subtitle}</p>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px', flexShrink: 0 }}>
                  <span style={{
                    fontSize: '9px', fontWeight: '900', padding: '2px 8px', borderRadius: '6px',
                    background: doc.tagColor + '20', color: doc.tagColor,
                  }}>
                    {doc.tag}
                  </span>
                  <span style={{ color: 'var(--primary)', fontSize: '14px' }}>→</span>
                </div>
              </button>
            ))}
          </div>
        </section>

      </main>
    </div>
  );
};

export default Advice;
